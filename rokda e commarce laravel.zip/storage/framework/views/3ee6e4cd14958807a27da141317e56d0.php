<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['title' => 'Shopping Cart']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Shopping Cart']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <div class="container-x py-6">
        <h1 class="text-2xl font-extrabold mb-5">Your Shopping Cart</h1>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($items->isEmpty()): ?>
            <div class="bg-white rounded-xl border border-line p-12 text-center text-muted">
                <i class="fa-solid fa-cart-shopping text-5xl mb-3 opacity-30"></i>
                <p class="mb-3">Your cart is empty.</p>
                <a href="<?php echo e(route('shop')); ?>" class="btn-brand h-10 px-6 inline-flex">Start Shopping</a>
            </div>
        <?php else: ?>
            <div class="grid lg:grid-cols-[1fr_320px] gap-6">
                
                <div class="bg-white rounded-xl border border-line divide-y divide-line min-w-0">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <div class="flex gap-4 p-4">
                            <a href="<?php echo e(route('product.show', $item['product'])); ?>" class="w-20 h-20 rounded-lg bg-canvas overflow-hidden shrink-0">
                                <img src="<?php echo e(image_url($item['product']->main_image, $item['product']->name)); ?>" class="w-full h-full object-cover">
                            </a>
                            <div class="flex-1 min-w-0">
                                <a href="<?php echo e(route('product.show', $item['product'])); ?>" class="font-semibold clamp-2"><?php echo e($item['product']->name); ?></a>
                                <div class="text-brand font-bold mt-1"><?php echo e(bdt($item['product']->price)); ?></div>
                                <div class="flex items-center gap-3 mt-2">
                                    <form method="POST" action="<?php echo e(route('cart.update', $item['key'])); ?>" class="flex items-center border border-line rounded-lg overflow-hidden">
                                        <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                        <button name="quantity" value="<?php echo e($item['quantity'] - 1); ?>" class="w-8 h-8 grid place-items-center hover:bg-canvas">−</button>
                                        <span class="w-10 h-8 grid place-items-center text-sm font-bold border-x border-line"><?php echo e($item['quantity']); ?></span>
                                        <button name="quantity" value="<?php echo e($item['quantity'] + 1); ?>" class="w-8 h-8 grid place-items-center hover:bg-canvas">+</button>
                                    </form>
                                    <button type="button" data-remove-cart="<?php echo e($item['key']); ?>" class="text-muted hover:text-sale text-sm flex items-center gap-1"><i class="fa-solid fa-trash-can"></i>Remove</button>
                                </div>
                            </div>
                            <div class="text-right font-bold"><?php echo e(bdt($item['subtotal'])); ?></div>
                        </div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </div>

                
                <div class="bg-white rounded-xl border border-line p-5 h-fit lg:sticky lg:top-32">
                    <h3 class="font-bold mb-4">Order Summary</h3>
                    <div class="flex justify-between text-sm mb-2">
                        <span class="text-muted">Subtotal</span>
                        <span class="font-semibold"><?php echo e(bdt($subtotal)); ?></span>
                    </div>
                    <div class="flex justify-between text-sm mb-3">
                        <span class="text-muted">Delivery</span>
                        <span class="text-muted">Calculated at checkout</span>
                    </div>
                    <div class="border-t border-line pt-3 flex justify-between font-bold text-lg">
                        <span>Total</span>
                        <span class="text-brand"><?php echo e(bdt($subtotal)); ?></span>
                    </div>
                    <a href="<?php echo e(route('checkout.index')); ?>" class="btn-accent w-full h-11 mt-4">Proceed to Checkout</a>
                    <a href="<?php echo e(route('shop')); ?>" class="block text-center text-sm text-brand mt-3 hover:underline">Continue Shopping</a>
                </div>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH F:\extrain web all project\rokdabd.com\rokda e commarce laravel\resources\views\cart.blade.php ENDPATH**/ ?>