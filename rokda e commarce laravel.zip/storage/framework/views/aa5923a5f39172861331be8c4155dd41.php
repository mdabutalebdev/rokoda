<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => ['title' => 'Order #'.e($order->order_number).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Order #'.e($order->order_number).'']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <a href="<?php echo e(route('admin.orders.index')); ?>" class="text-sm text-muted hover:text-brand mb-4 inline-block"><i class="fa-solid fa-arrow-left mr-1"></i>Orders</a>

    <div class="grid lg:grid-cols-[1fr_320px] gap-6">
        
        <div class="space-y-6">
            <div class="bg-white rounded-xl border border-line p-5">
                <div class="flex items-center justify-between mb-4">
                    <h2 class="font-bold">Order Items</h2>
                    <span class="text-xs text-muted"><?php echo e($order->created_at->format('d M Y, g:i A')); ?></span>
                </div>
                <div class="divide-y divide-line">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <div class="flex items-center gap-3 py-3">
                            <div class="flex-1"><div class="font-semibold text-sm"><?php echo e($item->name); ?></div><div class="text-xs text-muted"><?php echo e($item->quantity); ?> × <?php echo e(bdt($item->price)); ?></div></div>
                            <div class="font-bold"><?php echo e(bdt($item->subtotal)); ?></div>
                        </div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </div>
                <div class="border-t border-line mt-3 pt-3 space-y-1 text-sm">
                    <div class="flex justify-between"><span class="text-muted">Subtotal</span><span><?php echo e(bdt($order->subtotal)); ?></span></div>
                    <div class="flex justify-between"><span class="text-muted">Delivery</span><span><?php echo e(bdt($order->shipping_fee)); ?></span></div>
                    <div class="flex justify-between font-bold text-lg border-t border-line pt-2"><span>Total</span><span class="text-brand"><?php echo e(bdt($order->total)); ?></span></div>
                </div>
            </div>

            <div class="bg-white rounded-xl border border-line p-5 text-sm">
                <h2 class="font-bold mb-3">Customer & Delivery</h2>
                <div class="grid sm:grid-cols-2 gap-2 text-muted">
                    <div><span class="text-ink font-semibold">Name:</span> <?php echo e($order->name); ?></div>
                    <div><span class="text-ink font-semibold">Mobile:</span> <?php echo e($order->phone); ?></div>
                    <div class="sm:col-span-2"><span class="text-ink font-semibold">Address:</span> <?php echo e($order->address); ?><?php echo e($order->thana ? ', '.$order->thana : ''); ?><?php echo e($order->district ? ', '.$order->district : ''); ?><?php echo e($order->division ? ', '.$order->division : ''); ?></div>
                    <div><span class="text-ink font-semibold">Area:</span> <?php echo e($order->delivery_zone === 'inside_dhaka' ? 'Inside Dhaka' : 'Outside Dhaka'); ?></div>
                    <div><span class="text-ink font-semibold">Payment:</span> <?php echo e($order->payment_method === 'cod' ? 'Cash on Delivery' : 'Mobile Banking'); ?></div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($order->payment_method === 'mobile_banking'): ?>
                        <div><span class="text-ink font-semibold">Channel:</span> <?php echo e($order->payment_channel ? ucfirst($order->payment_channel) : '—'); ?></div>
                        <div><span class="text-ink font-semibold">Sender Number:</span> <?php echo e($order->payment_sender_number ?: '—'); ?></div>
                        <div><span class="text-ink font-semibold">Transaction ID:</span> <?php echo e($order->payment_txn_id ?: '—'); ?></div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($order->notes): ?><div class="sm:col-span-2"><span class="text-ink font-semibold">Note:</span> <?php echo e($order->notes); ?></div><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
        </div>

        
        <div class="bg-white rounded-xl border border-line p-5 h-fit">
            <h2 class="font-bold mb-4">Update Status</h2>
            <form method="POST" action="<?php echo e(route('admin.orders.status', $order)); ?>" class="space-y-3">
                <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                <div>
                    <label class="block text-sm font-medium mb-1">Order Status</label>
                    <select name="status" class="w-full h-11 rounded-lg border border-line px-3 text-sm bg-white">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = \App\Models\Order::STATUS_LABELS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <option value="<?php echo e($key); ?>" <?php if($order->status===$key): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Payment Status</label>
                    <select name="payment_status" class="w-full h-11 rounded-lg border border-line px-3 text-sm bg-white">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = ['unpaid' => 'Unpaid', 'paid' => 'Paid', 'failed' => 'Failed']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <option value="<?php echo e($key); ?>" <?php if($order->payment_status===$key): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </select>
                </div>
                <button class="btn-brand w-full h-11">Update</button>
            </form>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php /**PATH F:\extrain web all project\rokdabd.com\rokda e commarce laravel\resources\views\admin\orders\show.blade.php ENDPATH**/ ?>