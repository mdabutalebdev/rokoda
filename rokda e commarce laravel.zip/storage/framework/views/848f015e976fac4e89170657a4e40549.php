<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['product']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['product']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php $inWishlist = in_array($product->id, $wishlistIds ?? []); ?>

<div class="group bg-white rounded-md border border-line shadow-soft hover:shadow-card transition overflow-hidden flex flex-col h-full">
    <div class="relative overflow-hidden">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($product->discount_percent > 0): ?>
            <span class="absolute top-2 left-2 z-10 bg-accent text-white text-[11px] font-bold px-1.5 py-0.5 rounded">-<?php echo e($product->discount_percent); ?>%</span>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <a href="<?php echo e(route('product.show', $product)); ?>" class="block aspect-square bg-canvas overflow-hidden">
            <img src="<?php echo e(image_url($product->main_image, $product->name)); ?>" alt="<?php echo e($product->name); ?>" loading="lazy"
                 class="w-full h-full object-cover group-hover:scale-105 transition duration-300">
        </a>
    </div>

    <div class="p-2.5 flex flex-col flex-1">
        <h3 class="text-sm font-normal leading-snug clamp-2 min-h-[2.5em]">
            <a href="<?php echo e(route('product.show', $product)); ?>" class="hover:text-brand transition"><?php echo e($product->name); ?></a>
        </h3>

        <div class="flex items-center gap-1 mt-1">
            <?php $r = (int) round($product->rating); ?>
            <span class="flex text-[9px]">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php for($s = 1; $s <= 5; $s++): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <i class="fa-solid fa-star <?php echo e($s <= $r ? 'text-amber-400' : 'text-gray-300'); ?>"></i>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endfor; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </span>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($product->reviews_count): ?>
                <span class="text-muted text-[10px]">(<?php echo e($product->reviews_count); ?>)</span>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        <div class="flex items-center flex-wrap gap-x-2 mt-1.5">
            <span class="text-brand font-bold text-[13px]"><?php echo e(bdt($product->price)); ?></span>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($product->old_price && $product->old_price > $product->price): ?>
                <span class="text-muted text-[11px] line-through"><?php echo e(bdt($product->old_price)); ?></span>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        
        <?php
            $hasVariants = collect($product->attributes ?? [])
                ->contains(fn ($g) => !empty($g['name']) && !empty(array_filter($g['options'] ?? [])));
        ?>
        <div class="mt-2.5">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($hasVariants): ?>
                
                <a href="<?php echo e(route('product.show', $product)); ?>"
                   class="w-full h-9 rounded-lg text-sm font-medium flex items-center justify-center gap-1.5 border-2 border-accent text-accent bg-white hover:bg-accent hover:text-white transition-colors">
                    <i class="fa-solid fa-cart-plus"></i>Add to Cart
                </a>
            <?php else: ?>
                
                <button type="button" data-add-cart="<?php echo e($product->id); ?>"
                        class="w-full h-9 rounded-lg text-sm font-medium flex items-center justify-center gap-1.5 border-2 border-accent text-accent bg-white hover:bg-accent hover:text-white transition-colors">
                    <i class="fa-solid fa-cart-plus"></i>Add to Cart
                </button>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH F:\extrain web all project\rokdabd.com\rokda e commarce laravel\resources\views/components/product-card.blade.php ENDPATH**/ ?>