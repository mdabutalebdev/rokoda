<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['title' => 'Order Placed']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Order Placed']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <div class="container-x py-10 max-w-2xl mx-auto">
        <div class="bg-white rounded-xl border border-line p-6 text-center">
            <div class="w-16 h-16 rounded-full bg-brand-light text-brand grid place-items-center text-3xl mx-auto mb-4">
                <i class="fa-solid fa-circle-check"></i>
            </div>
            <h1 class="text-2xl font-extrabold">Thank you! Your order has been placed.</h1>
            <p class="text-muted mt-2">Order Number: <span class="font-bold text-ink"><?php echo e($order->order_number); ?></span></p>
            <p class="text-sm text-muted mt-1">We will contact you shortly at <?php echo e($order->phone); ?>.</p>
        </div>

        <div class="bg-white rounded-xl border border-line p-6 mt-5">
            <h2 class="font-bold mb-4">Order Details</h2>
            <div class="divide-y divide-line">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <div class="flex justify-between py-2 text-sm">
                        <span><?php echo e($item->name); ?> <span class="text-muted">× <?php echo e($item->quantity); ?></span></span>
                        <span class="font-semibold"><?php echo e(bdt($item->subtotal)); ?></span>
                    </div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </div>
            <div class="border-t border-line mt-3 pt-3 space-y-1 text-sm">
                <div class="flex justify-between"><span class="text-muted">Subtotal:</span><span><?php echo e(bdt($order->subtotal)); ?></span></div>
                <div class="flex justify-between"><span class="text-muted">Delivery:</span><span><?php echo e(bdt($order->shipping_fee)); ?></span></div>
                <div class="flex justify-between font-bold text-lg border-t border-line pt-2"><span>Total:</span><span class="text-brand"><?php echo e(bdt($order->total)); ?></span></div>
            </div>
        </div>

        <div class="bg-white rounded-xl border border-line p-6 mt-5 text-sm">
            <h2 class="font-bold mb-3">Delivery Information</h2>
            <div class="grid sm:grid-cols-2 gap-2 text-muted">
                <div><span class="text-ink font-semibold">Name:</span> <?php echo e($order->name); ?></div>
                <div><span class="text-ink font-semibold">Mobile:</span> <?php echo e($order->phone); ?></div>
                <div class="sm:col-span-2"><span class="text-ink font-semibold">Address:</span> <?php echo e($order->address); ?><?php echo e($order->thana ? ', '.$order->thana : ''); ?><?php echo e($order->district ? ', '.$order->district : ''); ?></div>
                <div><span class="text-ink font-semibold">Payment:</span> <?php echo e($order->payment_method === 'cod' ? 'Cash on Delivery' : 'Mobile Banking'); ?></div>
                <div><span class="text-ink font-semibold">Area:</span> <?php echo e($order->delivery_zone === 'inside_dhaka' ? 'Inside Dhaka' : 'Outside Dhaka'); ?></div>
            </div>
        </div>

        <div class="flex gap-3 mt-6 justify-center">
            <a href="<?php echo e(route('home')); ?>" class="h-11 px-6 rounded-lg border border-line bg-white inline-flex items-center font-semibold">Back to Home</a>
            <a href="<?php echo e(route('shop')); ?>" class="btn-accent h-11 px-6">Continue Shopping</a>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH F:\extrain web all project\rokdabd.com\rokda e commarce laravel\resources\views\checkout-confirmation.blade.php ENDPATH**/ ?>