<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['title' => $product->name]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product->name)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <?php
        $gallery = collect([$product->main_image])->merge($product->images->pluck('path'))->filter()->unique()->values();
        // Each gallery entry carries its media type so the viewer can render a
        // <video> for clips and an image (with hover-zoom) for photos.
        $galleryItems = $gallery->map(fn ($img) => [
            'url'  => image_url($img, $product->name),
            'type' => is_video($img) ? 'video' : 'image',
        ])->values();
        $reviews = $product->approvedReviews;
        $avg = $reviews->count() ? round($reviews->avg('rating'), 1) : $product->rating;
        $variants = collect($product->attributes ?? [])
            ->filter(fn ($g) => !empty($g['name']) && !empty(array_filter($g['options'] ?? [])))
            ->values();
    ?>

    <?php $variantNames = $variants->pluck('name')->values(); ?>
    <div class="container-x py-4" x-data="{ qty: 1, options: {}, required: <?php echo e($variantNames->toJson()); ?> }">
        
        <nav class="flex flex-wrap items-center gap-y-1 text-xs text-muted mb-3">
            <a href="<?php echo e(route('home')); ?>" class="hover:text-brand">Home</a>
            <span class="mx-1">/</span>
            <a href="<?php echo e(route('shop')); ?>" class="hover:text-brand">Shop</a>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($product->category): ?>
                <span class="mx-1">/</span>
                <a href="<?php echo e(route('shop', ['category' => $product->category->slug])); ?>" class="hover:text-brand"><?php echo e($product->category->name); ?></a>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <span class="mx-1">/</span>
            <span class="text-ink"><?php echo e($product->name); ?></span>
        </nav>

        <div class="bg-white rounded-xl border border-line p-3 sm:p-5 w-full min-w-0">
            <div class="grid md:grid-cols-2 gap-5 lg:gap-8 min-w-0">
                
                <div x-data="{ idx: 0, fullscreen: false, zoom: false, ox: 50, oy: 50, items: <?php echo e($galleryItems->toJson()); ?> }" class="flex flex-col gap-3 min-w-0">
                    
                    <div class="relative w-full rounded-xl border border-line overflow-hidden aspect-square bg-canvas group min-w-0">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($product->discount_percent > 0): ?>
                            <span class="absolute top-3 left-3 z-10 bg-accent text-white text-[11px] font-bold px-2 py-1 rounded">-<?php echo e($product->discount_percent); ?>%</span>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                        
                        <template x-if="items[idx].type === 'image'">
                            <div class="absolute inset-0 overflow-hidden"
                                 style="cursor: zoom-in;"
                                 @click="fullscreen = true"
                                 @mouseenter="zoom = true"
                                 @mouseleave="zoom = false"
                                 @mousemove="const r = $el.getBoundingClientRect(); ox = (($event.clientX - r.left) / r.width) * 100; oy = (($event.clientY - r.top) / r.height) * 100;">
                                <img :src="items[idx].url" alt="<?php echo e($product->name); ?>"
                                     class="w-full h-full object-contain"
                                     style="transition: transform .15s ease-out; user-select: none; will-change: transform;"
                                     :style="zoom ? `transform: scale(2.4); transform-origin: ${ox}% ${oy}%;` : 'transform: scale(1);'">
                                <div x-show="!zoom" style="pointer-events: none;" class="absolute inset-0 bg-black/0 group-hover:bg-black/5 transition flex items-center justify-center">
                                    <i class="fa-solid fa-magnifying-glass-plus text-3xl text-white opacity-0 group-hover:opacity-100 transition drop-shadow-md"></i>
                                </div>
                            </div>
                        </template>

                        
                        <template x-if="items[idx].type === 'video'">
                            <video :src="items[idx].url" controls playsinline preload="metadata"
                                   class="absolute inset-0 w-full h-full object-contain" style="background: #000;"></video>
                        </template>

                        <template x-if="items.length > 1">
                            <div>
                                <button type="button" @click.stop="zoom = false; idx = (idx - 1 + items.length) % items.length"
                                        class="absolute left-2 top-1/2 -translate-y-1/2 z-10 w-9 h-9 rounded-full bg-white/85 hover:bg-white grid place-items-center shadow text-ink">
                                    <i class="fa-solid fa-chevron-left"></i>
                                </button>
                                <button type="button" @click.stop="zoom = false; idx = (idx + 1) % items.length"
                                        class="absolute right-2 top-1/2 -translate-y-1/2 z-10 w-9 h-9 rounded-full bg-white/85 hover:bg-white grid place-items-center shadow text-ink">
                                    <i class="fa-solid fa-chevron-right"></i>
                                </button>
                            </div>
                        </template>
                    </div>

                    
                    <template x-teleport="body">
                        <div x-show="fullscreen" x-cloak @click.self="fullscreen = false" @keydown.escape.window="fullscreen = false" class="fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4 sm:p-8">
                            <button type="button" @click="fullscreen = false" class="absolute top-4 right-4 sm:top-8 sm:right-8 w-10 h-10 bg-white/10 hover:bg-white/30 text-white rounded-full flex items-center justify-center text-xl transition"><i class="fa-solid fa-xmark"></i></button>
                            
                            <template x-if="items[idx].type === 'image'">
                                <img :src="items[idx].url" class="max-w-full max-h-full object-contain">
                            </template>
                            <template x-if="items[idx].type === 'video'">
                                <video :src="items[idx].url" controls playsinline autoplay class="max-w-full max-h-full object-contain"></video>
                            </template>

                            <template x-if="items.length > 1">
                                <div>
                                    <button type="button" @click="idx = (idx - 1 + items.length) % items.length"
                                            class="absolute left-4 sm:left-8 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-white/10 hover:bg-white/30 text-white grid place-items-center text-xl transition">
                                        <i class="fa-solid fa-chevron-left"></i>
                                    </button>
                                    <button type="button" @click="idx = (idx + 1) % items.length"
                                            class="absolute right-4 sm:right-8 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-white/10 hover:bg-white/30 text-white grid place-items-center text-xl transition">
                                        <i class="fa-solid fa-chevron-right"></i>
                                    </button>
                                </div>
                            </template>
                        </div>
                    </template>

                    
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($gallery->count() > 1): ?>
                        <div class="relative group/thumb mt-2" x-data="{
                                scrollLeft() { $refs.thumbList.scrollBy({ left: -150, behavior: 'smooth' }); },
                                scrollRight() { $refs.thumbList.scrollBy({ left: 150, behavior: 'smooth' }); }
                            }">
                            
                            <button type="button" @click="scrollLeft()" class="absolute left-0 top-1/2 -translate-y-1/2 z-10 w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-white/90 shadow grid place-items-center opacity-0 group-hover/thumb:opacity-100 transition disabled:opacity-0" >
                                <i class="fa-solid fa-chevron-left text-xs sm:text-sm text-ink"></i>
                            </button>
                            
                            <div x-ref="thumbList" class="flex gap-2 overflow-x-auto snap-x snap-mandatory pb-1" style="scrollbar-width: none; -ms-overflow-style: none;">
                                <style>.group\\/thumb .overflow-x-auto::-webkit-scrollbar { display: none; }</style>
                                <template x-for="(it, i) in items" :key="i">
                                    <button type="button" @click="zoom = false; idx = i"
                                            class="relative shrink-0 w-16 sm:w-20 aspect-square rounded-lg border-2 overflow-hidden transition snap-center"
                                            :class="idx === i ? 'border-brand' : 'border-line hover:border-brand/40'">
                                        <template x-if="it.type === 'image'">
                                            <img :src="it.url" class="w-full h-full object-cover">
                                        </template>
                                        <template x-if="it.type === 'video'">
                                            <span class="block w-full h-full">
                                                <video :src="it.url" class="w-full h-full object-cover" muted preload="metadata"></video>
                                                <span class="absolute inset-0 grid place-items-center" style="background: rgba(0,0,0,.3);">
                                                    <i class="fa-solid fa-play text-white text-sm"></i>
                                                </span>
                                            </span>
                                        </template>
                                    </button>
                                </template>
                            </div>

                            
                            <button type="button" @click="scrollRight()" class="absolute right-0 top-1/2 -translate-y-1/2 z-10 w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-white/90 shadow grid place-items-center opacity-0 group-hover/thumb:opacity-100 transition disabled:opacity-0" >
                                <i class="fa-solid fa-chevron-right text-xs sm:text-sm text-ink"></i>
                            </button>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                
                <div class="min-w-0">
                    <h1 class="text-xl sm:text-2xl font-bold leading-snug break-words"><?php echo e($product->name); ?></h1>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($product->short_description): ?>
                        <p class="text-muted text-sm sm:text-base mt-1.5 leading-relaxed break-words"><?php echo e($product->short_description); ?></p>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <div class="flex items-center gap-2 mt-2">
                        <?php $r = (int) round($avg); ?>
                        <span class="flex text-[11px]">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php for($s = 1; $s <= 5; $s++): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <i class="fa-solid fa-star <?php echo e($s <= $r ? 'text-amber-400' : 'text-gray-300'); ?>"></i>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endfor; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </span>
                        <a href="#reviews" class="text-muted text-xs hover:text-brand">(<?php echo e($reviews->count()); ?> reviews)</a>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($product->stock > 0): ?>
                            <span class="ml-1 text-xs font-semibold text-brand bg-brand-light px-2.5 py-1 rounded-full">In Stock</span>
                        <?php else: ?>
                            <span class="ml-1 text-xs font-semibold text-sale bg-red-50 px-2.5 py-1 rounded-full">Out of Stock</span>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>

                    
                    <div class="bg-brand-light rounded-xl p-3 mt-3 flex items-center gap-3 flex-wrap">
                        <span class="text-brand font-bold text-2xl"><?php echo e(bdt($product->price)); ?></span>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($product->old_price && $product->old_price > $product->price): ?>
                            <span class="text-muted text-base line-through"><?php echo e(bdt($product->old_price)); ?></span>
                            <span class="bg-accent text-white text-[11px] font-bold px-2 py-1 rounded ml-auto">-<?php echo e($product->discount_percent); ?>% OFF</span>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>

                    
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($variants->isNotEmpty()): ?>
                        <?php
                            // Common colour names → CSS colour, so a "Color" variant renders as swatches.
                            $colorMap = [
                                'black' => '#111111', 'white' => '#ffffff', 'red' => '#ef4444', 'blue' => '#2563eb',
                                'green' => '#16a34a', 'yellow' => '#eab308', 'orange' => '#f97316', 'purple' => '#9333ea',
                                'pink' => '#ec4899', 'gray' => '#6b7280', 'grey' => '#6b7280', 'brown' => '#92400e',
                                'gold' => '#d4af37', 'silver' => '#cbd5e1', 'navy' => '#1e3a8a', 'maroon' => '#7f1d1d',
                                'teal' => '#14b8a6', 'cyan' => '#06b6d4', 'sky blue' => '#38bdf8', 'sky' => '#38bdf8',
                                'light blue' => '#93c5fd', 'dark blue' => '#1e40af', 'beige' => '#e8dcc4',
                                'কালো' => '#111111', 'সাদা' => '#ffffff', 'লাল' => '#ef4444', 'নীল' => '#2563eb',
                                'সবুজ' => '#16a34a', 'হলুদ' => '#eab308', 'কমলা' => '#f97316', 'গোলাপি' => '#ec4899',
                                'ধূসর' => '#6b7280', 'বাদামি' => '#92400e',
                            ];
                            $lightColors = ['white', 'সাদা', 'yellow', 'হলুদ', 'beige', 'silver', 'gold'];
                            $colorGroups = ['color', 'colour', 'কালার', 'কালার ফ্যামিলি', 'রং', 'রঙ'];
                        ?>
                        <div class="mt-4 space-y-3">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <?php
                                    $gName = $group['name'];
                                    $opts = array_values(array_filter($group['options'] ?? []));
                                    $isColor = in_array(mb_strtolower(trim($gName)), $colorGroups, true);
                                ?>
                                <div>
                                    <div class="text-sm font-semibold mb-1.5">নির্বাচন করুন: <span class="text-brand" x-text="options['<?php echo e($gName); ?>']"></span></div>

                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isColor): ?>
                                        
                                        <div class="flex flex-wrap gap-2.5">
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $opts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                                <?php
                                                    $key = mb_strtolower(trim($opt));
                                                    $hex = $colorMap[$key] ?? null;
                                                    $isLight = in_array($key, $lightColors, true);
                                                ?>
                                                <button type="button"
                                                        @click="options['<?php echo e($gName); ?>'] = '<?php echo e($opt); ?>'"
                                                        :class="options['<?php echo e($gName); ?>'] === '<?php echo e($opt); ?>' ? 'ring-2 ring-accent ring-offset-2' : 'ring-1 ring-line hover:ring-accent'"
                                                        class="relative w-9 h-9 rounded-full transition shrink-0"
                                                        style="background-color: <?php echo e($hex ?? '#e5e7eb'); ?>;"
                                                        title="<?php echo e($opt); ?>" aria-label="<?php echo e($opt); ?>">
                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if (! ($hex)): ?>
                                                        <span class="absolute inset-0 grid place-items-center text-[9px] font-bold text-ink"><?php echo e(mb_substr($opt, 0, 3)); ?></span>
                                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                    <span x-show="options['<?php echo e($gName); ?>'] === '<?php echo e($opt); ?>'" x-cloak class="absolute inset-0 grid place-items-center">
                                                        <i class="fa-solid fa-check text-xs <?php echo e($isLight ? 'text-ink' : 'text-white'); ?>"></i>
                                                    </span>
                                                </button>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                        </div>
                                    <?php else: ?>
                                        
                                        <div class="flex flex-wrap gap-2">
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $opts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                                <button type="button"
                                                        @click="options['<?php echo e($gName); ?>'] = '<?php echo e($opt); ?>'"
                                                        :class="options['<?php echo e($gName); ?>'] === '<?php echo e($opt); ?>' ? 'border-accent bg-accent text-white' : 'border-line hover:border-accent text-ink'"
                                                        class="px-3 h-9 rounded-lg border text-sm font-semibold transition bg-white">
                                                    <?php echo e($opt); ?>

                                                </button>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                        </div>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    
                    <form method="POST" action="<?php echo e(route('cart.add', $product)); ?>" class="grid grid-cols-2 gap-1 sm:gap-2 mt-5"
                          @submit="
                              const missing = required.filter(n => !options[n]);
                              if (missing.length) { $event.preventDefault(); alert('অনুগ্রহ করে নির্বাচন করুন: ' + missing.join(', ')); }
                          ">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="quantity" :value="qty">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <input type="hidden" :name="'options[<?php echo e($g['name']); ?>]'" :value="options['<?php echo e($g['name']); ?>'] || ''">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

                        
                        <div style="grid-column: 1 / -1;" class="flex items-center justify-center sm:justify-between border border-line rounded-lg overflow-hidden h-11 bg-white px-1 sm:px-3">
                            <span class="hidden sm:inline-block text-[13px] font-semibold text-muted">Qty.</span>
                            <div class="flex items-center h-full">
                                <button type="button" @click="qty = Math.max(1, qty - 1)" class="w-7 h-full grid place-items-center hover:bg-canvas text-lg">−</button>
                                <span class="w-6 h-full grid place-items-center font-bold text-sm" x-text="qty"></span>
                                <button type="button" @click="qty++" class="w-7 h-full grid place-items-center hover:bg-canvas text-lg">+</button>
                            </div>
                        </div>

                        
                        <button type="submit" name="redirect" value=""
                                class="h-11 rounded-lg border-2 border-brand text-brand text-xs sm:text-base font-bold hover:bg-brand-light transition flex items-center justify-center gap-1 sm:gap-1.5 px-1 sm:px-0">
                            <i class="fa-solid fa-cart-plus"></i><span class="whitespace-nowrap">Add to Cart</span>
                        </button>

                        
                        <button type="submit" name="redirect" value="checkout"
                                class="h-11 btn-accent text-xs sm:text-base flex items-center justify-center gap-1 sm:gap-1.5 px-1 sm:px-0">
                            <i class="fa-solid fa-bolt"></i><span class="whitespace-nowrap">Buy Now</span>
                        </button>
                    </form>


                </div>
            </div>
        </div>

        
        <div class="bg-white rounded-xl border border-line p-5 mt-5">
            <h2 class="font-bold text-base mb-3 flex items-center gap-2"><i class="fa-solid fa-circle-info text-brand"></i>Product Description</h2>
            <div class="text-base leading-relaxed text-ink/85 space-y-3 overflow-x-auto break-words
                        [&_p]:mb-2 [&_ul]:list-disc [&_ul]:pl-5 [&_ul]:space-y-1
                        [&_ol]:list-decimal [&_ol]:pl-5 [&_ol]:space-y-1
                        [&_strong]:text-ink [&_strong]:font-semibold
                        [&_h1]:text-lg [&_h1]:font-bold [&_h2]:text-base [&_h2]:font-bold
                        [&_h3]:text-sm [&_h3]:font-bold
                        [&_a]:text-brand [&_a:hover]:underline
                        [&_img]:rounded-lg [&_img]:my-3 [&_img]:max-w-full
                        [&_iframe]:w-full [&_iframe]:aspect-video [&_iframe]:rounded-lg [&_iframe]:my-3 [&_iframe]:h-auto
                        [&_table]:w-full [&_table]:block [&_table]:overflow-x-auto">
                <?php echo $product->description; ?>

            </div>
        </div>

        
        <div id="reviews" class="bg-white rounded-xl border border-line p-5 mt-5">
            <div class="grid md:grid-cols-[260px_1fr] gap-6">
                
                <div>
                    <h2 class="font-bold text-base mb-2">Customer Reviews</h2>
                    <div class="flex items-center gap-3 mb-3">
                        <span class="text-3xl font-extrabold text-brand"><?php echo e($avg); ?></span>
                        <div>
                            <div class="flex text-amber-400 text-xs">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php for($s = 1; $s <= 5; $s++): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?><i class="fa-solid fa-star <?php echo e($s <= round($avg) ? '' : 'text-gray-300'); ?>"></i><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endfor; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            </div>
                            <div class="text-[11px] text-muted mt-0.5"><?php echo e($reviews->count()); ?> review(s)</div>
                        </div>
                    </div>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
                        <div class="bg-brand-light border border-brand/20 text-brand rounded-lg p-3 mb-3 text-sm"><i class="fa-solid fa-circle-check mr-1"></i><?php echo e(session('success')); ?></div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->any()): ?>
                        <div class="bg-red-50 border border-red-200 text-sale rounded-lg p-3 mb-3 text-sm">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?><div><?php echo e($error); ?></div><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <form method="POST" action="<?php echo e(route('reviews.store')); ?>" class="space-y-3" x-data="{ rating: 5 }">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                        <input type="hidden" name="rating" x-model="rating">
                        <div>
                            <label class="block text-xs font-medium mb-1">Your Rating</label>
                            <div class="flex gap-1 text-xl text-amber-400">
                                <template x-for="s in 5" :key="s">
                                    <button type="button" @click="rating = s"><i class="fa-solid fa-star" :class="s <= rating ? '' : 'text-gray-300'"></i></button>
                                </template>
                            </div>
                        </div>
                        <div>
                            <label class="block text-xs font-medium mb-1">Name <span class="text-sale">*</span></label>
                            <input type="text" name="name" value="<?php echo e(old('name')); ?>" required class="w-full h-9 rounded-lg border border-line px-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30">
                        </div>
                        <div>
                            <label class="block text-xs font-medium mb-1">Email <span class="text-muted font-normal">(optional)</span></label>
                            <input type="email" name="email" value="<?php echo e(old('email')); ?>" class="w-full h-9 rounded-lg border border-line px-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30">
                        </div>
                        <div>
                            <label class="block text-xs font-medium mb-1">Review <span class="text-sale">*</span></label>
                            <textarea name="comment" rows="3" required class="w-full rounded-lg border border-line px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30"><?php echo e(old('comment')); ?></textarea>
                        </div>
                        <button type="submit" class="btn-brand h-10 px-6 w-full text-sm">Submit Review</button>
                    </form>
                </div>

                
                <div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <div class="border-b border-line pb-3 mb-3 last:border-0">
                            <div class="flex items-center gap-3 mb-1.5">
                                <span class="w-8 h-8 rounded-full bg-brand text-white grid place-items-center font-bold text-xs shrink-0"><?php echo e(mb_substr($review->name, 0, 1)); ?></span>
                                <div>
                                    <div class="font-semibold text-sm"><?php echo e($review->name); ?></div>
                                    <div class="flex text-amber-400 text-[11px]">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php for($s = 1; $s <= 5; $s++): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?><i class="fa-solid fa-star <?php echo e($s <= $review->rating ? '' : 'text-gray-300'); ?>"></i><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endfor; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                    </div>
                                </div>
                                <span class="ml-auto text-[11px] text-muted"><?php echo e($review->created_at->format('d M Y')); ?></span>
                            </div>
                            <p class="text-xs text-ink/80 leading-relaxed break-words"><?php echo e($review->comment); ?></p>
                        </div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        <div class="text-center text-muted py-8">
                            <i class="fa-regular fa-comment-dots text-3xl mb-2 opacity-30"></i>
                            <p class="text-sm">No reviews yet. Be the first to review this product!</p>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
        </div>

        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($related->isNotEmpty()): ?>
            <div class="mt-6">
                <h2 class="text-base font-extrabold mb-3 flex items-center gap-2"><span class="w-1.5 h-6 rounded-full bg-accent inline-block"></span>Related Products</h2>
                <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.product-card','data' => ['product' => $rel]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('product-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($rel)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a)): ?>
<?php $attributes = $__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a; ?>
<?php unset($__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a)): ?>
<?php $component = $__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a; ?>
<?php unset($__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a); ?>
<?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </div>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH F:\extrain web all project\rokdabd.com\rokda e commarce laravel\resources\views\product-details.blade.php ENDPATH**/ ?>