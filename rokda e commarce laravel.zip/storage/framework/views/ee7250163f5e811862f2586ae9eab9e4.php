<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['title' => 'Track Order']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Track Order']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <div class="container-x py-6 max-w-2xl mx-auto">
        <h1 class="text-2xl font-extrabold mb-1">Track Your Order</h1>
        <p class="text-muted text-sm mb-5">Enter your order number to see its current status.</p>

        
        <form method="GET" action="<?php echo e(route('track')); ?>" class="bg-white rounded-xl border border-line p-4 flex flex-col sm:flex-row gap-3">
            <input type="text" name="order_number" value="<?php echo e(request('order_number')); ?>" placeholder="e.g. RM260807XXXXX" required
                   class="flex-1 h-11 rounded-lg border border-line px-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30">
            <button type="submit" class="btn-brand h-11 px-6 shrink-0"><i class="fa-solid fa-magnifying-glass"></i>Track</button>
        </form>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($searched && ! $order): ?>
            <div class="bg-white rounded-xl border border-line p-8 text-center text-muted mt-5">
                <i class="fa-solid fa-box-open text-4xl mb-3 opacity-30"></i>
                <p>No order found with this number. Please check and try again.</p>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($order): ?>
            <div class="bg-white rounded-xl border border-line p-5 mt-5">
                <div class="flex items-center justify-between flex-wrap gap-2 border-b border-line pb-4 mb-4">
                    <div>
                        <div class="text-xs text-muted">Order Number</div>
                        <div class="font-bold"><?php echo e($order->order_number); ?></div>
                        <div class="text-xs text-muted mt-1"><?php echo e($order->created_at->format('d M Y, h:i A')); ?></div>
                    </div>
                    <span class="text-sm font-semibold px-3 py-1.5 rounded-full bg-brand-light text-brand">
                        <?php echo e(\App\Models\Order::STATUS_LABELS[$order->status] ?? $order->status); ?>

                    </span>
                </div>

                
                <div class="divide-y divide-line">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <div class="flex justify-between py-2 text-sm gap-3">
                            <span class="min-w-0"><?php echo e($item->name); ?> <span class="text-muted">× <?php echo e($item->quantity); ?></span></span>
                            <span class="font-semibold shrink-0"><?php echo e(bdt($item->subtotal)); ?></span>
                        </div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </div>

                <div class="border-t border-line mt-3 pt-3 space-y-1 text-sm">
                    <div class="flex justify-between"><span class="text-muted">Subtotal:</span><span><?php echo e(bdt($order->subtotal)); ?></span></div>
                    <div class="flex justify-between"><span class="text-muted">Delivery:</span><span><?php echo e(bdt($order->shipping_fee)); ?></span></div>
                    <div class="flex justify-between font-bold text-lg border-t border-line pt-2"><span>Total:</span><span class="text-brand"><?php echo e(bdt($order->total)); ?></span></div>
                </div>

                <div class="mt-4 pt-4 border-t border-line text-sm text-muted space-y-1">
                    <div><span class="text-ink font-semibold">Name:</span> <?php echo e($order->name); ?></div>
                    <div><span class="text-ink font-semibold">Mobile:</span> <?php echo e($order->phone); ?></div>
                    <div><span class="text-ink font-semibold">Address:</span> <?php echo e($order->address); ?><?php echo e($order->thana ? ', '.$order->thana : ''); ?><?php echo e($order->district ? ', '.$order->district : ''); ?></div>
                    <div><span class="text-ink font-semibold">Payment:</span> <?php echo e($order->payment_method === 'cod' ? 'Cash on Delivery' : 'Mobile Banking'); ?></div>
                </div>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH F:\extrain web all project\rokdabd.com\rokda e commarce laravel\resources\views\track-order.blade.php ENDPATH**/ ?>