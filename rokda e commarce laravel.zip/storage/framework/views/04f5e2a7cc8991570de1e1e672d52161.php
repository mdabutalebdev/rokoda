<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['title' => 'My Account']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'My Account']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <div class="container-x py-6">
        <div class="flex items-center justify-between mb-5">
            <h1 class="text-2xl font-extrabold">My Account</h1>
            <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
                <button class="h-10 px-4 rounded-lg border border-line bg-white text-sm font-semibold hover:bg-canvas"><i class="fa-solid fa-right-from-bracket mr-1"></i>Logout</button>
            </form>
        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
            <div class="bg-brand-light border border-brand/20 text-brand rounded-lg p-3 mb-4 text-sm"><i class="fa-solid fa-circle-check mr-1"></i><?php echo e(session('success')); ?></div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <div class="grid lg:grid-cols-[320px_1fr] gap-6">
            
            <div class="bg-white rounded-xl border border-line p-5 h-fit">
                <div class="flex items-center gap-3 mb-4">
                    <span class="w-14 h-14 rounded-full bg-brand text-white grid place-items-center text-xl font-bold"><?php echo e(mb_substr($user->name, 0, 1)); ?></span>
                    <div class="min-w-0">
                        <div class="font-bold truncate"><?php echo e($user->name); ?></div>
                        <div class="text-xs text-muted truncate"><?php echo e($user->email); ?></div>
                    </div>
                </div>
                <form method="POST" action="<?php echo e(route('account.update')); ?>" class="space-y-3">
                    <?php echo csrf_field(); ?>
                    <div>
                        <label class="block text-xs font-medium mb-1 text-muted">Name</label>
                        <input type="text" name="name" value="<?php echo e(old('name', $user->name)); ?>" class="w-full h-10 rounded-lg border border-line px-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30">
                    </div>
                    <div>
                        <label class="block text-xs font-medium mb-1 text-muted">Phone</label>
                        <input type="text" name="phone" value="<?php echo e(old('phone', $user->phone)); ?>" class="w-full h-10 rounded-lg border border-line px-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30">
                    </div>
                    <div>
                        <label class="block text-xs font-medium mb-1 text-muted">City</label>
                        <input type="text" name="city" value="<?php echo e(old('city', $user->city)); ?>" class="w-full h-10 rounded-lg border border-line px-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30">
                    </div>
                    <div>
                        <label class="block text-xs font-medium mb-1 text-muted">Address</label>
                        <textarea name="address" rows="2" class="w-full rounded-lg border border-line px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30"><?php echo e(old('address', $user->address)); ?></textarea>
                    </div>
                    <button class="btn-brand w-full h-10 text-sm">Update Profile</button>
                </form>
            </div>

            
            <div class="bg-white rounded-xl border border-line p-5">
                <h2 class="font-bold mb-4 flex items-center gap-2"><i class="fa-solid fa-bag-shopping text-brand"></i>My Orders</h2>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($orders->isEmpty()): ?>
                    <div class="text-center text-muted py-10">
                        <i class="fa-solid fa-box-open text-4xl mb-2 opacity-30"></i>
                        <p>You have no orders yet.</p>
                        <a href="<?php echo e(route('shop')); ?>" class="text-brand font-semibold text-sm mt-2 inline-block">Start Shopping →</a>
                    </div>
                <?php else: ?>
                    <div class="space-y-3">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <div class="border border-line rounded-lg p-3 flex items-center justify-between flex-wrap gap-2">
                                <div>
                                    <div class="font-semibold text-sm"><?php echo e($order->order_number); ?></div>
                                    <div class="text-xs text-muted"><?php echo e($order->created_at->format('d M Y')); ?> · <?php echo e($order->items_count ?? $order->items->count()); ?> items</div>
                                </div>
                                <div class="flex items-center gap-3">
                                    <span class="text-xs font-semibold px-2 py-1 rounded-full bg-brand-light text-brand"><?php echo e(\App\Models\Order::STATUS_LABELS[$order->status] ?? $order->status); ?></span>
                                    <span class="font-bold text-brand"><?php echo e(bdt($order->total)); ?></span>
                                </div>
                            </div>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH F:\extrain web all project\rokdabd.com\rokda e commarce laravel\resources\views\account-dashboard.blade.php ENDPATH**/ ?>