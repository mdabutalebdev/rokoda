<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['title' => $page['title']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($page['title'])]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <div class="container-x py-8 max-w-3xl mx-auto">
        <nav class="text-xs text-muted mb-3">
            <a href="<?php echo e(route('home')); ?>" class="hover:text-brand">Home</a>
            <span class="mx-1">/</span>
            <span class="text-ink"><?php echo e($page['title']); ?></span>
        </nav>

        <div class="bg-white rounded-xl border border-line p-6 sm:p-8">
            <h1 class="text-2xl font-extrabold mb-5 flex items-center gap-2">
                <span class="w-1.5 h-7 rounded-full bg-accent inline-block"></span><?php echo e($page['title']); ?>

            </h1>
            <div class="prose-sm text-sm text-ink/80 leading-relaxed space-y-3 [&_ul]:space-y-1 [&_ol]:space-y-1 [&_strong]:text-ink">
                <?php echo $page['body']; ?>

            </div>

            <div class="mt-6 pt-5 border-t border-line text-sm text-muted">
                Still need help? Contact us at
                <a href="mailto:<?php echo e($page['contact']['email']); ?>" class="text-brand font-semibold"><?php echo e($page['contact']['email']); ?></a>
                or <a href="tel:<?php echo e($page['contact']['phone']); ?>" class="text-brand font-semibold"><?php echo e($page['contact']['phone']); ?></a>.
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH F:\extrain web all project\rokdabd.com\rokda e commarce laravel\resources\views\page.blade.php ENDPATH**/ ?>