<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => ['title' => 'Orders']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Orders']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <form method="GET" class="flex items-center gap-2 mb-4 flex-wrap">
        <div class="relative flex-1 max-w-xs">
            <input type="text" name="q" value="<?php echo e(request('q')); ?>" placeholder="Search order/phone..." class="w-full h-10 rounded-lg border border-line pl-9 pr-3 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-brand/30">
            <i class="fa-solid fa-magnifying-glass absolute left-3 top-3 text-muted text-sm"></i>
        </div>
        <select name="status" onchange="this.form.submit()" class="h-10 rounded-lg border border-line px-3 text-sm bg-white">
            <option value="">All Statuses</option>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = \App\Models\Order::STATUS_LABELS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <option value="<?php echo e($key); ?>" <?php if(request('status')===$key): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </select>
        <button class="h-10 px-4 rounded-lg bg-brand text-white text-sm font-semibold">Filter</button>
    </form>

    <div x-data="{ 
        selectAll: false, 
        selected: [], 
        toggleAll() { 
            this.selectAll = !this.selectAll; 
            if(this.selectAll) { this.selected = <?php echo e($orders->pluck('id')->toJson()); ?>; } else { this.selected = []; }
        }
    }">
        <form method="POST" action="<?php echo e(route('admin.orders.bulk_print')); ?>" target="_blank">
            <?php echo csrf_field(); ?>
            <div class="flex justify-end mb-3" x-show="selected.length > 0" x-cloak>
                <button type="submit" class="h-10 px-4 rounded-lg bg-ink text-white text-sm font-semibold flex items-center gap-2">
                    <i class="fa-solid fa-print"></i> Print Selected Invoices (<span x-text="selected.length"></span>)
                </button>
            </div>

            <div class="bg-white rounded-xl border border-line overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="w-full text-sm">
                        <thead class="bg-canvas text-muted text-left">
                            <tr>
                                <th class="px-4 py-3 w-10"><input type="checkbox" @click="toggleAll()" :checked="selectAll" class="accent-brand w-4 h-4 rounded border-line"></th>
                                <th class="px-4 py-3 font-semibold">Order No</th>
                                <th class="px-4 py-3 font-semibold">Customer</th>
                                <th class="px-4 py-3 font-semibold">Products</th>
                                <th class="px-4 py-3 font-semibold">Total</th>
                                <th class="px-4 py-3 font-semibold">Payment</th>
                                <th class="px-4 py-3 font-semibold">Status</th>
                                <th class="px-4 py-3 font-semibold text-right"></th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-line">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <tr class="hover:bg-canvas">
                                    <td class="px-4 py-3"><input type="checkbox" name="order_ids[]" value="<?php echo e($order->id); ?>" x-model="selected" class="accent-brand w-4 h-4 rounded border-line"></td>
                                    <td class="px-4 py-3"><a href="<?php echo e(route('admin.orders.show', $order)); ?>" class="font-semibold text-brand"><?php echo e($order->order_number); ?></a><div class="text-xs text-muted"><?php echo e($order->created_at->format('d M, g:i A')); ?></div></td>
                                    <td class="px-4 py-3"><?php echo e($order->name); ?><div class="text-xs text-muted"><?php echo e($order->phone); ?></div></td>
                                    <td class="px-4 py-3"><?php echo e($order->items_count); ?> items</td>
                                    <td class="px-4 py-3 font-bold"><?php echo e(bdt($order->total)); ?></td>
                                    <td class="px-4 py-3"><span class="text-xs"><?php echo e($order->payment_method === 'cod' ? 'COD' : 'Mobile'); ?></span></td>
                                    <td class="px-4 py-3"><span class="text-xs font-semibold px-2 py-1 rounded-full bg-brand-light text-brand"><?php echo e(\App\Models\Order::STATUS_LABELS[$order->status] ?? $order->status); ?></span></td>
                                    <td class="px-4 py-3 text-right"><a href="<?php echo e(route('admin.orders.show', $order)); ?>" class="text-brand"><i class="fa-solid fa-eye"></i></a></td>
                                </tr>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                <tr><td colspan="8" class="px-4 py-10 text-center text-muted">No orders yet.</td></tr>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </form>
    </div>

    <div class="mt-4"><?php echo e($orders->links()); ?></div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php /**PATH F:\extrain web all project\rokdabd.com\rokda e commarce laravel\resources\views\admin\orders\index.blade.php ENDPATH**/ ?>