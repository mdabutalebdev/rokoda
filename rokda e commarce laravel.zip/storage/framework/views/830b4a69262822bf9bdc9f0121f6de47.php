<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'size' => 'md',            // sm | md | lg
    'primary' => 'text-brand', // colour of the first word
    'secondary' => 'text-accent', // colour of the remaining words
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'size' => 'md',            // sm | md | lg
    'primary' => 'text-brand', // colour of the first word
    'secondary' => 'text-accent', // colour of the remaining words
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    // Dynamic: the shop owner can rename the brand from Admin → Settings (site_name).
    $brandName = trim(\App\Models\SiteSetting::get('site_name') ?: 'Rokda');
    $parts = explode(' ', $brandName, 2);

    $top = [
        'sm' => 'text-base',
        'md' => 'text-lg sm:text-2xl',
        'lg' => 'text-2xl sm:text-3xl',
    ][$size] ?? 'text-lg sm:text-2xl';

    $bottom = [
        'sm' => 'text-[10px]',
        'md' => 'text-[10px] sm:text-[11px]',
        'lg' => 'text-[11px] sm:text-[13px]',
    ][$size] ?? 'text-[10px] sm:text-[11px]';
?>

<span <?php echo e($attributes->merge(['class' => 'inline-block leading-none select-none'])); ?>>
    <span class="block font-extrabold uppercase <?php echo e($primary); ?> <?php echo e($top); ?>" style="letter-spacing:-.01em"><?php echo e($parts[0]); ?></span>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($parts[1])): ?>
        <span class="block font-semibold uppercase <?php echo e($secondary); ?> <?php echo e($bottom); ?>" style="letter-spacing:.32em"><?php echo e($parts[1]); ?></span>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</span>
<?php /**PATH F:\extrain web all project\rokdabd.com\rokda e commarce laravel\resources\views/components/brand-wordmark.blade.php ENDPATH**/ ?>