<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['title' => $title]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <?php
        $collections = [
            'flash_sale' => 'Flash Sale',
            'featured' => 'Featured',
            'best_seller' => 'Best Selling',
            'new_arrival' => 'New Arrival',
        ];
        $hasFilters = $selectedCategories->isNotEmpty() || $selectedFlags->isNotEmpty()
            || request()->hasAny(['min_price', 'max_price', 'in_stock', 'out_of_stock']);
    ?>

    
    <section class="bg-white border-b border-line">
        <div class="container-x py-6">
            <nav class="text-xs text-muted mb-1">
                <a href="<?php echo e(route('home')); ?>" class="hover:text-brand">Home</a>
                <span class="mx-1">/</span>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($activeCategory): ?>
                    <a href="<?php echo e(route('shop')); ?>" class="hover:text-brand">Shop</a>
                    <span class="mx-1">/</span>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <span class="text-ink"><?php echo e($title); ?></span>
            </nav>
            <h1 class="text-2xl font-extrabold"><?php echo e($title); ?></h1>
            <p class="text-muted text-sm mt-1">Explore our collection of genuine, quality products.</p>
        </div>
    </section>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(($categoryBanners ?? collect())->isNotEmpty()): ?>
        <div class="container-x pt-6"
             x-data="{ i: 0, n: <?php echo e($categoryBanners->count()); ?>,
                       init() { if (this.n > 1) setInterval(() => { this.i = (this.i + 1) % this.n }, 5000) } }">
            <div class="relative rounded-2xl overflow-hidden shadow-card bg-brand-light" style="height: clamp(120px, 18vw, 260px);">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $categoryBanners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <a href="<?php echo e($banner->link ?: '#'); ?>" <?php if(empty($banner->link)): ?> onclick="return false" <?php endif; ?>
                       class="absolute inset-0"
                       x-show="i === <?php echo e($idx); ?>" x-transition.opacity.duration.600ms
                       <?php if($idx !== 0): ?> style="display:none" <?php endif; ?>>
                        <img src="<?php echo e(image_url($banner->image, $activeCategory->name)); ?>" alt="<?php echo e($banner->title ?? $activeCategory->name); ?>"
                             class="w-full h-full object-cover">
                    </a>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($categoryBanners->count() > 1): ?>
                    <div class="absolute bottom-3 inset-x-0 flex justify-center gap-1.5 z-10">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $categoryBanners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <button type="button" @click="i = <?php echo e($idx); ?>" aria-label="Slide <?php echo e($idx + 1); ?>"
                                    class="w-2.5 h-2.5 rounded-full transition"
                                    :class="i === <?php echo e($idx); ?> ? 'bg-accent' : 'bg-white/60 hover:bg-white'"></button>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <style>
        @media (min-width: 1024px) { #shop-sidebar { display: block !important; } }
    </style>

    <div class="container-x py-6 grid lg:grid-cols-[270px_1fr] gap-6" x-data="{ filtersOpen: false }">
        
        <aside id="shop-sidebar" :class="filtersOpen ? 'block' : 'hidden'">
            <form method="GET" action="<?php echo e(route('shop')); ?>" class="bg-white rounded-xl border border-line divide-y divide-line overflow-hidden sticky top-24">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(request('sort')): ?><input type="hidden" name="sort" value="<?php echo e(request('sort')); ?>"><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <div class="flex items-center justify-between p-4">
                    <h3 class="font-bold flex items-center gap-2"><i class="fa-solid fa-sliders text-brand"></i>Filters</h3>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($hasFilters): ?>
                        <a href="<?php echo e(route('shop')); ?>" class="text-xs text-sale font-semibold hover:underline">Clear All</a>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                
                <div class="p-4"
                     x-data="{
                        floor: <?php echo e($priceFloor); ?>, ceil: <?php echo e(max($priceCeil, $priceFloor + 1)); ?>,
                        min: <?php echo e($minPrice); ?>, max: <?php echo e($maxPrice); ?>,
                        get span(){ return Math.max(1, this.ceil - this.floor) },
                        get lp(){ return (this.min - this.floor) / this.span * 100 },
                        get rp(){ return 100 - (this.max - this.floor) / this.span * 100 },
                        submitForm(){ this.$root.closest('form').submit() }
                     }">
                    <h4 class="text-sm font-bold mb-3">Price Range</h4>
                    <div class="flex justify-between text-sm font-semibold text-ink mb-3">
                        <span>৳<span x-text="min"></span></span>
                        <span>৳<span x-text="max"></span></span>
                    </div>
                    <div class="range-track mx-1.5">
                        <div class="range-fill" :style="`left:${lp}%; right:${rp}%`"></div>
                        <input type="range" :min="floor" :max="ceil" step="1" x-model.number="min"
                               @input="if(min > max) min = max" @change="submitForm()">
                        <input type="range" :min="floor" :max="ceil" step="1" x-model.number="max"
                               @input="if(max < min) max = min" @change="submitForm()">
                    </div>
                    <input type="hidden" name="min_price" :value="min">
                    <input type="hidden" name="max_price" :value="max">
                    <div class="flex justify-between text-[11px] text-muted mt-2">
                        <span>৳<?php echo e(number_format($priceFloor)); ?></span>
                        <span>৳<?php echo e(number_format($priceCeil)); ?></span>
                    </div>
                </div>

                
                <div class="p-4" x-data="{ showAll: <?php echo e($selectedCategories->isNotEmpty() ? 'true' : 'false'); ?> }">
                    <h4 class="text-sm font-bold mb-3">Categories</h4>
                    <div class="space-y-2">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <label class="flex items-center gap-2 text-sm cursor-pointer <?php echo e($i >= 5 ? '' : ''); ?>"
                                   <?php if($i >= 5): ?> x-show="showAll" x-cloak <?php endif; ?>>
                                <input type="checkbox" name="categories[]" value="<?php echo e($cat->slug); ?>"
                                       <?php if($selectedCategories->contains($cat->slug)): echo 'checked'; endif; ?>
                                       onchange="this.form.submit()" class="accent-brand">
                                <span class="flex-1"><?php echo e($cat->name); ?></span>
                                <span class="text-xs text-muted"><?php echo e($categoryCounts[$cat->slug] ?? 0); ?></span>
                            </label>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($categories->count() > 5): ?>
                        <button type="button" @click="showAll = !showAll" class="text-xs text-brand font-semibold mt-2.5 hover:underline">
                            <span x-show="!showAll">See All (<?php echo e($categories->count()); ?>) ↓</span>
                            <span x-show="showAll" x-cloak>Show Less ↑</span>
                        </button>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                
                <div class="p-4">
                    <h4 class="text-sm font-bold mb-3">Availability</h4>
                    <div class="space-y-2">
                        <label class="flex items-center gap-2 text-sm cursor-pointer">
                            <input type="checkbox" name="in_stock" value="1" <?php if(request()->boolean('in_stock')): echo 'checked'; endif; ?> onchange="this.form.submit()" class="accent-brand">
                            <span class="flex-1">In Stock</span>
                            <span class="text-xs text-muted"><?php echo e($availabilityCounts['in_stock'] ?? 0); ?></span>
                        </label>
                        <label class="flex items-center gap-2 text-sm cursor-pointer">
                            <input type="checkbox" name="out_of_stock" value="1" <?php if(request()->boolean('out_of_stock')): echo 'checked'; endif; ?> onchange="this.form.submit()" class="accent-brand">
                            <span class="flex-1">Out of Stock</span>
                            <span class="text-xs text-muted"><?php echo e($availabilityCounts['out_of_stock'] ?? 0); ?></span>
                        </label>
                    </div>
                </div>

                
                <div class="p-4">
                    <h4 class="text-sm font-bold mb-3">Collections</h4>
                    <div class="space-y-2">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $collections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <label class="flex items-center gap-2 text-sm cursor-pointer">
                                <input type="checkbox" name="flags[]" value="<?php echo e($key); ?>"
                                       <?php if($selectedFlags->contains($key)): echo 'checked'; endif; ?>
                                       onchange="this.form.submit()" class="accent-brand">
                                <span class="flex-1"><?php echo e($label); ?></span>
                                <span class="text-xs text-muted"><?php echo e($flagCounts[$key] ?? 0); ?></span>
                            </label>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </div>
                </div>
            </form>
        </aside>

        
        <div class="min-w-0">
            
            <div class="flex items-center justify-between mb-4 gap-3">
                <div class="flex items-center gap-2">
                    <button type="button" @click="filtersOpen = !filtersOpen" class="lg:hidden h-10 px-3 rounded-lg border border-line bg-white text-sm font-semibold inline-flex items-center gap-2">
                        <i class="fa-solid fa-sliders text-brand"></i>Filters
                    </button>
                    <p class="text-sm text-muted"><?php echo e($products->total()); ?> products</p>
                </div>
                <form method="GET" class="flex items-center gap-2">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = request()->except(['sort','page']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(is_array($v)): ?>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $v; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?><input type="hidden" name="<?php echo e($k); ?>[]" value="<?php echo e($vv); ?>"><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        <?php else: ?>
                            <input type="hidden" name="<?php echo e($k); ?>" value="<?php echo e($v); ?>">
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    <label class="text-sm text-muted hidden sm:block">Sort:</label>
                    <select name="sort" onchange="this.form.submit()" class="h-10 rounded-lg border border-line bg-white px-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30">
                        <option value="" <?php if(request('sort')===''): echo 'selected'; endif; ?>>Default</option>
                        <option value="newest" <?php if(request('sort')==='newest'): echo 'selected'; endif; ?>>Newest</option>
                        <option value="price_low" <?php if(request('sort')==='price_low'): echo 'selected'; endif; ?>>Price: Low to High</option>
                        <option value="price_high" <?php if(request('sort')==='price_high'): echo 'selected'; endif; ?>>Price: High to Low</option>
                        <option value="popular" <?php if(request('sort')==='popular'): echo 'selected'; endif; ?>>Top Rated</option>
                    </select>
                </form>
            </div>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($products->isEmpty()): ?>
                <div class="bg-white rounded-xl border border-line p-12 text-center text-muted">
                    <i class="fa-solid fa-box-open text-5xl mb-3 opacity-30"></i>
                    <p>No products found. Try adjusting your filters.</p>
                </div>
            <?php else: ?>
                <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.product-card','data' => ['product' => $product]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('product-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a)): ?>
<?php $attributes = $__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a; ?>
<?php unset($__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a)): ?>
<?php $component = $__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a; ?>
<?php unset($__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a); ?>
<?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </div>

                <div class="mt-8">
                    <?php echo e($products->links()); ?>

                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH F:\extrain web all project\rokdabd.com\rokda e commarce laravel\resources\views\shop.blade.php ENDPATH**/ ?>