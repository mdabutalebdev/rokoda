
<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($testimonials->isNotEmpty()): ?>
    <section data-row class="container-x mt-12">
        <div class="flex items-end justify-between mb-5">
            <div>
                <h2 class="text-xl sm:text-2xl font-extrabold">What Our Customers Say</h2>
                <p class="text-muted text-sm mt-1">Real reviews from happy shoppers across Bangladesh</p>
            </div>
            <div class="hidden sm:flex items-center gap-2">
                <button type="button" data-row-prev class="w-9 h-9 rounded-full border border-line bg-white grid place-items-center hover:bg-accent hover:text-white hover:border-accent transition"><i class="fa-solid fa-chevron-left text-xs"></i></button>
                <button type="button" data-row-next class="w-9 h-9 rounded-full border border-line bg-white grid place-items-center hover:bg-accent hover:text-white hover:border-accent transition"><i class="fa-solid fa-chevron-right text-xs"></i></button>
            </div>
        </div>
        <div data-row-scroll class="flex gap-4 overflow-x-auto no-scrollbar snap-x pb-2">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <div class="w-80 max-w-[85%] shrink-0 snap-start bg-white rounded-xl border border-line shadow-soft p-5 flex flex-col">
                    <div class="flex items-center justify-between mb-3">
                        <div class="flex text-amber-400 text-sm">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php for($s = 1; $s <= 5; $s++): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?><i class="fa-solid fa-star <?php echo e($s <= $t->rating ? '' : 'text-gray-300'); ?>"></i><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endfor; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </div>
                        <i class="fa-solid fa-quote-right text-2xl text-accent/40"></i>
                    </div>
                    <p class="text-sm text-ink/80 leading-relaxed mb-4 flex-1">“<?php echo e($t->text); ?>”</p>
                    <div class="flex items-center gap-3 pt-3 border-t border-line">
                        <span class="w-10 h-10 rounded-full bg-accent text-white grid place-items-center font-bold shrink-0"><?php echo e(mb_substr($t->name, 0, 1)); ?></span>
                        <div class="min-w-0">
                            <div class="font-semibold text-sm truncate"><?php echo e($t->name); ?></div>
                            <div class="text-xs text-muted"><?php echo e($t->location); ?></div>
                        </div>
                        <span class="ml-auto text-accent text-xs font-semibold flex items-center gap-1"><i class="fa-solid fa-circle-check"></i>Verified</span>
                    </div>
                </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>
    </section>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php /**PATH F:\extrain web all project\rokdabd.com\rokda e commarce laravel\resources\views/partials/reviews.blade.php ENDPATH**/ ?>