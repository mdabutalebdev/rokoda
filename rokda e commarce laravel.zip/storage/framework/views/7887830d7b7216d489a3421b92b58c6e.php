<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => ['title' => 'Dashboard']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Dashboard']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <?php
        $cards = [
            ['label' => 'Total Revenue', 'value' => bdt($stats['revenue']), 'icon' => 'fa-sack-dollar', 'grad' => 'from-teal-500 to-emerald-600'],
            ['label' => 'Total Orders', 'value' => $stats['orders'], 'icon' => 'fa-bag-shopping', 'grad' => 'from-orange-500 to-amber-500'],
            ['label' => 'Pending Orders', 'value' => $stats['pending'], 'icon' => 'fa-clock', 'grad' => 'from-rose-500 to-pink-600'],
            ['label' => 'Products', 'value' => $stats['products'], 'icon' => 'fa-box', 'grad' => 'from-blue-500 to-indigo-600'],
            ['label' => 'Customers', 'value' => $stats['customers'], 'icon' => 'fa-users', 'grad' => 'from-violet-500 to-purple-600'],
            ['label' => 'Pending Reviews', 'value' => $stats['reviews'], 'icon' => 'fa-star', 'grad' => 'from-cyan-500 to-sky-600'],
        ];
        $maxSale = collect($salesChart)->max('value') ?: 1;
    ?>

    
    <div class="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <div class="rounded-2xl p-5 text-white bg-gradient-to-br <?php echo e($card['grad']); ?> shadow-card">
                <span class="w-10 h-10 rounded-xl bg-white/20 grid place-items-center text-lg mb-3"><i class="fa-solid <?php echo e($card['icon']); ?>"></i></span>
                <div class="text-2xl font-extrabold leading-tight"><?php echo e($card['value']); ?></div>
                <div class="text-sm text-white/85 mt-0.5"><?php echo e($card['label']); ?></div>
            </div>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
    </div>

    <div class="grid lg:grid-cols-[1fr_320px] gap-6 mt-6">
        
        <div class="bg-white rounded-2xl border border-line p-5">
            <div class="flex items-center justify-between mb-5">
                <h2 class="font-bold">Revenue — Last 7 Days</h2>
                <span class="text-xs text-muted">Total orders value per day</span>
            </div>
            <div class="flex items-end justify-between gap-2 sm:gap-4 h-52">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $salesChart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <div class="flex-1 flex flex-col items-center gap-2 group">
                        <div class="text-[10px] font-bold text-brand opacity-0 group-hover:opacity-100 transition"><?php echo e(bdt($bar['value'])); ?></div>
                        <div class="w-full rounded-t-lg bg-gradient-to-t from-brand to-teal-400 transition-all hover:from-accent hover:to-orange-400"
                             style="height: <?php echo e(max(4, round($bar['value'] / $maxSale * 100))); ?>%"></div>
                        <span class="text-xs text-muted"><?php echo e($bar['label']); ?></span>
                    </div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </div>
        </div>

        
        <div class="space-y-6">
            <div class="bg-white rounded-2xl border border-line p-5">
                <h2 class="font-bold mb-4">Orders by Status</h2>
                <div class="space-y-2.5">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = \App\Models\Order::STATUS_LABELS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <?php $c = $statusBreakdown[$key] ?? 0; $pct = $stats['orders'] ? round($c / $stats['orders'] * 100) : 0; ?>
                        <div>
                            <div class="flex justify-between text-xs mb-1"><span class="font-medium"><?php echo e($label); ?></span><span class="text-muted"><?php echo e($c); ?></span></div>
                            <div class="h-2 rounded-full bg-canvas overflow-hidden"><div class="h-full rounded-full bg-brand" style="width: <?php echo e($pct); ?>%"></div></div>
                        </div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="grid lg:grid-cols-[1fr_320px] gap-6 mt-6">
        
        <div class="bg-white rounded-2xl border border-line">
            <div class="flex items-center justify-between p-5 border-b border-line">
                <h2 class="font-bold">Recent Orders</h2>
                <a href="<?php echo e(route('admin.orders.index')); ?>" class="text-brand text-sm font-semibold hover:underline">View All →</a>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead class="bg-canvas text-muted text-left">
                        <tr>
                            <th class="px-5 py-3 font-semibold">Order</th>
                            <th class="px-5 py-3 font-semibold">Customer</th>
                            <th class="px-5 py-3 font-semibold">Total</th>
                            <th class="px-5 py-3 font-semibold">Status</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-line">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $recentOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <tr class="hover:bg-canvas">
                                <td class="px-5 py-3"><a href="<?php echo e(route('admin.orders.show', $order)); ?>" class="font-semibold text-brand"><?php echo e($order->order_number); ?></a></td>
                                <td class="px-5 py-3"><?php echo e($order->name); ?><div class="text-xs text-muted"><?php echo e($order->phone); ?></div></td>
                                <td class="px-5 py-3 font-bold"><?php echo e(bdt($order->total)); ?></td>
                                <td class="px-5 py-3"><span class="text-xs font-semibold px-2 py-1 rounded-full bg-brand-light text-brand"><?php echo e(\App\Models\Order::STATUS_LABELS[$order->status] ?? $order->status); ?></span></td>
                            </tr>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            <tr><td colspan="4" class="px-5 py-8 text-center text-muted">No orders yet.</td></tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        
        <div class="bg-white rounded-2xl border border-line p-5">
            <h2 class="font-bold mb-4">Top Selling Products</h2>
            <div class="space-y-3">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $topProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <div class="flex items-center gap-3">
                        <img src="<?php echo e(image_url($p->main_image, $p->name)); ?>" class="w-10 h-10 rounded-lg object-cover border border-line shrink-0">
                        <div class="min-w-0 flex-1">
                            <div class="text-sm font-medium truncate"><?php echo e($p->name); ?></div>
                            <div class="text-xs text-muted"><?php echo e($p->order_items_count); ?> sold</div>
                        </div>
                        <span class="text-sm font-bold text-brand"><?php echo e(bdt($p->price)); ?></span>
                    </div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    <p class="text-sm text-muted">No data yet.</p>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php /**PATH F:\extrain web all project\rokdabd.com\rokda e commarce laravel\resources\views\admin\dashboard.blade.php ENDPATH**/ ?>