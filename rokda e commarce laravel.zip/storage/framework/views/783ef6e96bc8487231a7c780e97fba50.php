<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => ['title' => 'Social Links']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Social Links']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <div class="bg-white rounded-lg border border-line overflow-hidden">
        <div class="p-4 border-b border-line flex justify-between items-center bg-canvas/50">
            <h2 class="font-semibold">Social Links Settings</h2>
        </div>
        <div class="p-4">
            <form action="<?php echo e(route('admin.social-links.bulk-update')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <table class="w-full text-left text-sm mb-4">
                    <thead class="bg-canvas border-b border-line text-muted">
                        <tr>
                            <th class="px-4 py-3 font-medium w-16 text-center">Active</th>
                            <th class="px-4 py-3 font-medium w-48">Platform</th>
                            <th class="px-4 py-3 font-medium">URL</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-line">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <tr class="hover:bg-canvas/50 transition-colors">
                            <td class="px-4 py-3 text-center">
                                <input type="hidden" name="links[<?php echo e($link->id); ?>][id]" value="<?php echo e($link->id); ?>">
                                <input type="hidden" name="links[<?php echo e($link->id); ?>][is_active]" value="0">
                                <input type="checkbox" name="links[<?php echo e($link->id); ?>][is_active]" value="1" <?php echo e($link->is_active ? 'checked' : ''); ?> class="w-4 h-4 text-brand bg-white border-line rounded focus:ring-brand focus:ring-2 cursor-pointer">
                            </td>
                            <td class="px-4 py-3">
                                <div class="flex items-center gap-3">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($link->icon_class): ?>
                                    <div class="w-8 h-8 rounded bg-canvas grid place-items-center text-muted"><i class="<?php echo e($link->icon_class); ?>"></i></div>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    <span class="font-medium"><?php echo e($link->name); ?></span>
                                </div>
                            </td>
                            <td class="px-4 py-3">
                                <input type="url" name="links[<?php echo e($link->id); ?>][url]" value="<?php echo e($link->url); ?>" class="w-full bg-white border border-line text-sm rounded-lg focus:ring-brand focus:border-brand block px-3 py-2" placeholder="https://...">
                            </td>
                        </tr>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        <tr>
                            <td colspan="3" class="px-4 py-8 text-center text-muted">No social links found. Please run the seeder.</td>
                        </tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
                <div class="flex justify-end">
                    <button type="submit" class="h-10 px-6 rounded-lg bg-brand text-white font-medium hover:bg-brand-dark transition-colors">Save Settings</button>
                </div>
            </form>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php /**PATH F:\extrain web all project\rokdabd.com\rokda e commarce laravel\resources\views\admin\social_links\index.blade.php ENDPATH**/ ?>