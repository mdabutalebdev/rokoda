<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => ['title' => 'Delivery Charge Settings']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Delivery Charge Settings']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <div class="bg-white rounded-lg border border-line overflow-hidden max-w-3xl">
        <div class="p-4 border-b border-line flex justify-between items-center bg-canvas/50">
            <h2 class="font-semibold">Delivery Charge Settings</h2>
        </div>
        <div class="p-4">
            <form action="<?php echo e(route('admin.delivery-charge.update')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="space-y-4 mb-6">
                    <div>
                        <label for="shipping_inside_dhaka" class="block text-sm font-medium text-ink mb-1">Inside Dhaka Delivery Charge (৳)</label>
                        <input type="number" name="shipping_inside_dhaka" id="shipping_inside_dhaka" value="<?php echo e($settings['shipping_inside_dhaka'] ?? 60); ?>" class="w-full bg-white border border-line text-sm rounded-lg focus:ring-brand focus:border-brand block px-3 py-2" required min="0">
                    </div>
                    <div>
                        <label for="shipping_outside_dhaka" class="block text-sm font-medium text-ink mb-1">Outside Dhaka Delivery Charge (৳)</label>
                        <input type="number" name="shipping_outside_dhaka" id="shipping_outside_dhaka" value="<?php echo e($settings['shipping_outside_dhaka'] ?? 120); ?>" class="w-full bg-white border border-line text-sm rounded-lg focus:ring-brand focus:border-brand block px-3 py-2" required min="0">
                    </div>
                    <div>
                        <label for="free_shipping_threshold" class="block text-sm font-medium text-ink mb-1">Free Delivery Above Amount (৳)</label>
                        <p class="text-xs text-muted mb-2">If a customer's cart total reaches this amount, their delivery charge will automatically become ৳ 0.</p>
                        <input type="number" name="free_shipping_threshold" id="free_shipping_threshold" value="<?php echo e($settings['free_shipping_threshold'] ?? 1000000); ?>" class="w-full bg-white border border-line text-sm rounded-lg focus:ring-brand focus:border-brand block px-3 py-2" required min="0">
                    </div>
                </div>
                <div class="flex justify-end">
                    <button type="submit" class="h-10 px-6 rounded-lg bg-brand text-white font-medium hover:bg-brand-dark transition-colors">Save Delivery Charges</button>
                </div>
            </form>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php /**PATH F:\extrain web all project\rokdabd.com\rokda e commarce laravel\resources\views\admin\delivery_charge\index.blade.php ENDPATH**/ ?>