<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    
    <style>
        [data-hero-dot] { background-color: rgba(244, 102, 26, 0.5) !important; }
        [data-hero-dot].bg-accent, [data-hero-dot].bg-white { background-color: rgba(244, 102, 26, 1) !important; opacity: 1 !important; }
    </style>
    <section class="container-x pt-3 sm:pt-4">
        <div data-hero class="relative rounded-2xl overflow-hidden shadow-card bg-brand-light">
            <div data-hero-track class="flex transition-transform duration-500 ease-out">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $centerSlides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <a href="<?php echo e($slide->link ?? '#'); ?>" class="w-full shrink-0 block">
                        <img src="<?php echo e(image_url($slide->image, 'Rokda')); ?>" alt="<?php echo e($slide->title); ?>"
                             class="w-full aspect-[16/6] sm:aspect-[16/5] object-cover">
                    </a>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    <div class="w-full aspect-[16/6] sm:aspect-[16/5] bg-accent grid place-items-center text-white text-2xl font-bold tracking-wide">Rokda</div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($centerSlides->count() > 1): ?>
                <button type="button" data-hero-prev class="absolute left-2 sm:left-4 top-1/2 -translate-y-1/2 w-9 h-9 sm:w-11 sm:h-11 rounded-full bg-white/85 hover:bg-white grid place-items-center shadow text-ink">
                    <i class="fa-solid fa-chevron-left"></i>
                </button>
                <button type="button" data-hero-next class="absolute right-2 sm:right-4 top-1/2 -translate-y-1/2 w-9 h-9 sm:w-11 sm:h-11 rounded-full bg-white/85 hover:bg-white grid place-items-center shadow text-ink">
                    <i class="fa-solid fa-chevron-right"></i>
                </button>
                <div class="absolute bottom-3 inset-x-0 flex justify-center gap-1.5">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $centerSlides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <button type="button" data-hero-dot class="w-2.5 h-2.5 rounded-full bg-white/50 <?php echo e($i === 0 ? 'bg-accent' : ''); ?>"></button>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </section>

    
    <section class="container-x mt-4">
        <div class="rounded-xl overflow-hidden grid grid-cols-1 sm:grid-cols-3 text-white" style="background: var(--color-brand-dark);">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = [
                ['fa-shield-halved', 'Safe Payment', 'নিরাপদ পেমেন্ট'],
                ['fa-truck-fast', 'Fast Delivery', 'দ্রুত ডেলিভারি'],
                ['fa-rotate-left', 'Free Return', '৩ দিনে রিটার্ন'],
            ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <div class="flex items-center justify-center gap-3 py-3.5 px-4 <?php echo e($i > 0 ? 'sm:border-l border-white/10' : ''); ?>">
                    <i class="fa-solid <?php echo e($t[0]); ?> text-accent text-xl"></i>
                    <div class="leading-tight">
                        <div class="font-bold text-sm"><?php echo e($t[1]); ?></div>
                        <div class="text-white/70 text-xs"><?php echo e($t[2]); ?></div>
                    </div>
                </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>
    </section>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($categories->isNotEmpty()): ?>
        <style>
            .mcat-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: .75rem; }
            @media (min-width: 768px) { .mcat-grid { grid-template-columns: repeat(4, 1fr); gap: 1rem; } }

            .mcat-card {
                position: relative; display: block; overflow: hidden;
                border-radius: 14px; aspect-ratio: 1350 / 690;
                border: 1px solid var(--color-line);
                box-shadow: 0 2px 8px rgba(16, 24, 40, .06);
                background: var(--color-brand-light);
            }
            .mcat-card img { position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; transition: transform .4s ease; }
            .mcat-card:hover img { transform: scale(1.06); }
            .mcat-card:hover { box-shadow: 0 12px 30px rgba(16, 24, 40, .16); }

            /* Name label — only shown when we fall back to the plain square image. */
            .mcat-label {
                position: absolute; left: 0; right: 0; bottom: 0;
                padding: 1.5rem .75rem .6rem;
                background: linear-gradient(to top, rgba(0, 0, 0, .74), rgba(0, 0, 0, 0));
                color: #fff; font-weight: 700; font-size: .8125rem; line-height: 1.2;
            }
            @media (min-width: 640px) { .mcat-label { font-size: .9rem; } }

            /* Coloured fallback tile when a category has no image at all. */
            .mcat-fallback {
                position: absolute; inset: 0;
                display: flex; flex-direction: column; gap: .5rem;
                align-items: center; justify-content: center;
                text-align: center; padding: .5rem; color: #fff;
                background: linear-gradient(135deg, var(--color-brand), var(--color-brand-dark));
            }
            .mcat-fallback i { font-size: 1.9rem; }
            .mcat-fallback span { font-weight: 700; font-size: .8125rem; line-height: 1.2; }

            .mcat-all {
                display: inline-flex; align-items: center; gap: .5rem;
                color: var(--color-brand); font-weight: 700; font-size: .95rem;
                background: none; border: 1px solid var(--color-brand); cursor: pointer;
                padding: .6rem 1.5rem; border-radius: 999px; line-height: 1;
                transition: background-color .15s ease, color .15s ease;
            }
            .mcat-all:hover { background: var(--color-brand); color: #fff; }
        </style>

        <section class="container-x mt-8" x-data="{ showAll: false }">
            <div class="flex items-center justify-between mb-4">
                <h2 class="text-lg sm:text-xl font-extrabold flex items-center gap-2">
                    <span class="w-1.5 h-6 rounded-full bg-accent inline-block"></span>ক্যাটাগরি
                </h2>
            </div>

            
            <div class="mcat-grid">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <a href="<?php echo e(route('shop', ['category' => $cat->slug])); ?>"
                       class="mcat-card" aria-label="<?php echo e($cat->name); ?>"
                       <?php if($loop->index >= 8): ?> x-show="showAll" x-cloak <?php endif; ?>>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($cat->promo_image): ?>
                            <img src="<?php echo e(image_url($cat->promo_image, $cat->name)); ?>" alt="<?php echo e($cat->name); ?>" loading="lazy">
                        <?php elseif($cat->image): ?>
                            <img src="<?php echo e(image_url($cat->image, $cat->name)); ?>" alt="<?php echo e($cat->name); ?>" loading="lazy">
                            <span class="mcat-label"><?php echo e($cat->name); ?></span>
                        <?php else: ?>
                            <span class="mcat-fallback"><i class="<?php echo e($cat->icon ?? 'fa-solid fa-tag'); ?>"></i><span><?php echo e($cat->name); ?></span></span>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </a>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </div>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($categories->count() > 8): ?>
                <div class="text-center mt-6">
                    <button type="button" @click="showAll = !showAll" class="mcat-all">
                        <span x-show="!showAll">See All Categories <i class="fa-solid fa-chevron-down"></i></span>
                        <span x-show="showAll" x-cloak>Show Less <i class="fa-solid fa-chevron-up"></i></span>
                    </button>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </section>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <?php echo $__env->make('partials.product-row', ['title' => 'Flash Sale',   'icon' => '⚡', 'products' => $flashSale,   'viewAll' => route('shop', ['flash_sale' => 1])], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('partials.product-row', ['title' => 'Featured',     'icon' => '⭐', 'products' => $featured,    'viewAll' => route('shop', ['featured' => 1])], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('partials.product-row', ['title' => 'Best Selling', 'icon' => '🔥', 'products' => $bestSelling, 'viewAll' => route('shop', ['best_seller' => 1])], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('partials.product-row', ['title' => 'New Arrival',  'icon' => '🆕', 'products' => $newArrival,  'viewAll' => route('shop', ['new_arrival' => 1])], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($homeProducts->total() > 0): ?>
        <section class="container-x mt-10"
                 x-data="{
                    page: 1,
                    loading: false,
                    hasMore: <?php echo e($homeProducts->hasMorePages() ? 'true' : 'false'); ?>,
                    async loadMore() {
                        if (this.loading || !this.hasMore) return;
                        this.loading = true;
                        const next = this.page + 1;
                        try {
                            const res = await fetch(`<?php echo e(route('home.load-more')); ?>?page=${next}`, { headers: { 'X-Requested-With': 'XMLHttpRequest' } });
                            const data = await res.json();
                            this.$refs.grid.insertAdjacentHTML('beforeend', data.html);
                            this.page = next;
                            this.hasMore = data.hasMore;
                        } catch (e) {
                            console.error('Load more failed', e);
                        } finally {
                            this.loading = false;
                        }
                    }
                 }">
            <div class="flex items-center justify-between mb-4">
                <h2 class="text-lg font-extrabold flex items-center gap-2">
                    <span class="w-1.5 h-6 rounded-full bg-accent inline-block"></span>All Products
                </h2>
                <a href="<?php echo e(route('shop')); ?>" class="text-brand text-sm font-semibold hover:underline">View All →</a>
            </div>

            <div x-ref="grid" class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
                <?php echo $__env->make('partials.home-products', ['products' => $homeProducts], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>

            <div class="text-center mt-6" x-show="hasMore" x-cloak>
                <button type="button" @click="loadMore()" :disabled="loading"
                        class="btn-brand h-11 px-8 inline-flex items-center justify-center gap-2 disabled:opacity-60">
                    <span x-show="!loading">Load More</span>
                    <span x-show="loading" x-cloak class="inline-flex items-center gap-2"><i class="fa-solid fa-spinner fa-spin"></i> Loading...</span>
                </button>
            </div>
        </section>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <?php echo $__env->make('partials.reviews', ['testimonials' => $testimonials], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <section class="container-x mt-12">
        <div class="grid grid-cols-2 md:grid-cols-4 gap-3">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = [
                ['fa-truck-fast', 'Free Delivery', 'On selected orders'],
                ['fa-money-bill-wave', 'Cash on Delivery', 'Pay when you receive'],
                ['fa-rotate-left', 'Easy Return', 'Within 3 days'],
                ['fa-headset', '24/7 Support', 'Anytime, anywhere'],
            ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $badge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <div class="bg-white rounded-xl border border-line p-4 flex items-center gap-3">
                    <span class="w-11 h-11 rounded-full bg-accent-light text-accent grid place-items-center text-lg shrink-0"><i class="fa-solid <?php echo e($badge[0]); ?>"></i></span>
                    <div>
                        <div class="font-bold text-sm"><?php echo e($badge[1]); ?></div>
                        <div class="text-xs text-muted"><?php echo e($badge[2]); ?></div>
                    </div>
                </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH F:\extrain web all project\rokdabd.com\rokda e commarce laravel\resources\views/home.blade.php ENDPATH**/ ?>