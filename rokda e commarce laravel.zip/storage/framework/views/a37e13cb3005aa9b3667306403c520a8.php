<footer class="text-white mt-10" style="background-color: #0f2249;">
    <div class="container-x py-10 grid grid-cols-2 md:grid-cols-4 gap-8 text-sm">
        <div class="col-span-2 md:col-span-1">
            <div class="bg-white rounded-lg px-3 py-2.5 inline-block mb-3">
                <img src="<?php echo e(asset('images/rokda logo.jpeg')); ?>" alt="<?php echo e($settings['site_name'] ?? 'Rokda'); ?>" class="h-12 w-auto object-contain">
            </div>
            <p class="leading-relaxed"><?php echo e($settings['footer_text'] ?? 'Rokda - Your trusted online shopping platform.'); ?></p>
            <div class="flex items-center gap-2.5 mt-4 text-base">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($socialLinks) && $socialLinks->count() > 0): ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $socialLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <a href="<?php echo e($link->url); ?>" target="_blank" aria-label="<?php echo e($link->name); ?>" class="w-9 h-9 grid place-items-center rounded-full bg-accent text-white hover:opacity-80 transition"><i class="<?php echo e($link->icon_class ?? 'fa-solid fa-link'); ?>"></i></a>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>

        <div>
            <h4 class="text-white font-bold mb-3">Information</h4>
            <ul class="space-y-2">
                <li><a href="<?php echo e(route('page', 'about')); ?>" class="hover:text-white transition">About Us</a></li>
                <li><a href="<?php echo e(route('contact')); ?>" class="hover:text-white transition">Contact Us</a></li>
                <li><a href="<?php echo e(route('page', 'terms')); ?>" class="hover:text-white transition">Terms &amp; Conditions</a></li>
                <li><a href="<?php echo e(route('page', 'privacy')); ?>" class="hover:text-white transition">Privacy Policy</a></li>
                <li><a href="<?php echo e(route('page', 'refund-policy')); ?>" class="hover:text-white transition">Return &amp; Refund</a></li>
            </ul>
        </div>

        <div>
            <h4 class="text-white font-bold mb-3">Support</h4>
            <ul class="space-y-2">
                <li><a href="<?php echo e(route('page', 'how-to-order')); ?>" class="hover:text-white transition">How to Order</a></li>
                <li><a href="<?php echo e(route('track')); ?>" class="hover:text-white transition">Order Tracking</a></li>
                <li><a href="<?php echo e(route('page', 'shipping')); ?>" class="hover:text-white transition">Shipping &amp; Delivery</a></li>
                <li><a href="<?php echo e(route('page', 'faq')); ?>" class="hover:text-white transition">FAQ</a></li>
                <li><a href="<?php echo e(route('wishlist.index')); ?>" class="hover:text-white transition">Wishlist</a></li>
            </ul>
        </div>

        <div>
            <h4 class="text-white font-bold mb-3">Contact Us</h4>
            <ul class="space-y-2">
                <li class="flex items-start gap-2"><i class="fa-solid fa-location-dot mt-1 text-white"></i><span><?php echo e($settings['address'] ?? 'Dhaka, Bangladesh'); ?></span></li>
                <li><a href="tel:<?php echo e($settings['phone'] ?? ''); ?>" class="flex items-center gap-2 hover:text-white"><i class="fa-solid fa-phone text-white"></i><?php echo e($settings['phone'] ?? ''); ?></a></li>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($settings['whatsapp'])): ?><li><a href="https://wa.me/<?php echo e($settings['whatsapp']); ?>" target="_blank" class="flex items-center gap-2 hover:text-white"><i class="fa-brands fa-whatsapp text-white"></i>WhatsApp</a></li><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <li><a href="mailto:<?php echo e($settings['email'] ?? ''); ?>" class="flex items-center gap-2 hover:text-white"><i class="fa-solid fa-envelope text-white"></i><?php echo e($settings['email'] ?? ''); ?></a></li>
            </ul>
            <div class="flex items-center gap-2 mt-4 text-white text-xs">
                <i class="fa-solid fa-truck-fast"></i> Cash on Delivery available
            </div>
        </div>
    </div>

    <div class="border-t border-white/10">
        <div class="container-x py-4 text-xs text-white flex flex-col sm:flex-row items-center sm:justify-between gap-1.5">
            <div>Copyright © <?php echo e(max((int) date('Y'), 2026)); ?> <span class="font-semibold text-white"><?php echo e($settings['site_name'] ?? 'Rokda'); ?></span></div>
            <div class="flex items-center gap-1 text-white/80">
                Created by:
                <a href="https://www.extrainweb.com/" target="_blank" rel="noopener" class="font-semibold text-white hover:text-accent transition">Extrain Web</a>
            </div>
        </div>
    </div>
</footer>

<?php /**PATH F:\extrain web all project\rokdabd.com\rokda e commarce laravel\resources\views\partials\footer.blade.php ENDPATH**/ ?>