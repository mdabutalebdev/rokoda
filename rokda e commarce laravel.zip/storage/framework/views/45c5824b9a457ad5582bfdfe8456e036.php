<?php $__env->startSection('title', __('Server Error')); ?>
<?php $__env->startSection('code', '500'); ?>
<?php $__env->startSection('message', __('Server Error')); ?>

<?php echo $__env->make('errors::minimal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\extrain web all project\rokdabd.com\rokda e commarce laravel\vendor\laravel\framework\src\Illuminate\Foundation\Exceptions\views\500.blade.php ENDPATH**/ ?>