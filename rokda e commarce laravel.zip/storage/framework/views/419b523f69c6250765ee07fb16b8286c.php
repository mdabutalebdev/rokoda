
<nav class="lg:hidden fixed bottom-0 inset-x-0 z-40 bg-white border-t border-line shadow-[0_-2px_10px_rgba(0,0,0,0.05)]">
    <div class="grid grid-cols-5 h-16">
        <a href="<?php echo e(route('home')); ?>" class="flex flex-col items-center justify-center gap-1 text-[11px] <?php echo e(request()->routeIs('home') ? 'text-brand' : 'text-muted'); ?>">
            <i class="fa-solid fa-house text-lg"></i><?php echo e(__('messages.home')); ?>

        </a>
        <a href="<?php echo e(route('shop')); ?>" class="flex flex-col items-center justify-center gap-1 text-[11px] <?php echo e(request()->routeIs('shop') ? 'text-brand' : 'text-muted'); ?>">
            <i class="fa-solid fa-grip text-lg"></i><?php echo e(__('messages.shop')); ?>

        </a>
        <a href="<?php echo e(route('wishlist.index')); ?>" class="relative flex flex-col items-center justify-center gap-1 text-[11px] <?php echo e(request()->routeIs('wishlist.*') ? 'text-brand' : 'text-muted'); ?>">
            <i class="fa-regular fa-heart text-lg"></i><?php echo e(__('messages.wishlist')); ?>

            <span data-wishlist-count class="absolute top-2 right-5 min-w-4 h-4 px-1 rounded-full bg-sale text-white text-[9px] font-bold grid place-items-center <?php echo e(($wishlistCount ?? 0) === 0 ? 'hidden' : ''); ?>"><?php echo e($wishlistCount ?? 0); ?></span>
        </a>
        <button type="button" @click="cartOpen = true" class="relative flex flex-col items-center justify-center gap-1 text-[11px] text-muted">
            <i class="fa-solid fa-cart-shopping text-lg"></i><?php echo e(__('messages.cart')); ?>

            <span data-cart-count class="absolute top-2 right-5 min-w-4 h-4 px-1 rounded-full bg-sale text-white text-[9px] font-bold grid place-items-center <?php echo e(($cartCount ?? 0) === 0 ? 'hidden' : ''); ?>"><?php echo e($cartCount ?? 0); ?></span>
        </button>
        <a href="<?php echo e(route('account')); ?>" class="flex flex-col items-center justify-center gap-1 text-[11px] <?php echo e(request()->routeIs('account') ? 'text-brand' : 'text-muted'); ?>">
            <i class="fa-regular fa-user text-lg"></i><?php echo e(__('messages.account')); ?>

        </a>
    </div>
</nav>
<?php /**PATH F:\extrain web all project\rokdabd.com\rokda e commarce laravel\resources\views/partials/mobile-nav.blade.php ENDPATH**/ ?>