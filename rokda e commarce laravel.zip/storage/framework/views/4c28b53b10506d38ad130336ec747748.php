<?php $__env->startSection('title', __('Page Expired')); ?>
<?php $__env->startSection('code', '419'); ?>
<?php $__env->startSection('message', __('Page Expired')); ?>

<?php echo $__env->make('errors::minimal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\extrain web all project\rokdabd.com\rokda e commarce laravel\vendor\laravel\framework\src\Illuminate\Foundation\Exceptions\views\419.blade.php ENDPATH**/ ?>