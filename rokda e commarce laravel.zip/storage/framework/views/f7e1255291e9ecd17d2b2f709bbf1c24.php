
<div class="hidden lg:block bg-canvas text-muted text-[13px] border-b border-line">
    <div class="container-x flex items-center justify-between h-9">
        <div class="flex items-center gap-4">
            <a href="tel:<?php echo e($settings['phone'] ?? ''); ?>" class="flex items-center gap-1.5 hover:text-accent transition">
                <i class="fa-solid fa-phone text-accent"></i><?php echo e($settings['phone'] ?? ''); ?>

            </a>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($settings['email'])): ?>
                <span class="w-px h-4 bg-line"></span>
                <a href="mailto:<?php echo e($settings['email']); ?>" class="flex items-center gap-1.5 hover:text-accent transition">
                    <i class="fa-solid fa-envelope text-accent"></i><?php echo e($settings['email']); ?>

                </a>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
        <div class="flex items-center gap-4">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($settings['facebook'])): ?><a href="<?php echo e($settings['facebook']); ?>" target="_blank" class="hover:text-accent transition"><i class="fa-brands fa-facebook-f"></i></a><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($settings['instagram'])): ?><a href="<?php echo e($settings['instagram']); ?>" target="_blank" class="hover:text-accent transition"><i class="fa-brands fa-instagram"></i></a><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($settings['youtube'])): ?><a href="<?php echo e($settings['youtube']); ?>" target="_blank" class="hover:text-accent transition"><i class="fa-brands fa-youtube"></i></a><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($settings['tiktok'])): ?><a href="<?php echo e($settings['tiktok']); ?>" target="_blank" class="hover:text-accent transition"><i class="fa-brands fa-tiktok"></i></a><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($settings['telegram'])): ?><a href="<?php echo e($settings['telegram']); ?>" target="_blank" class="hover:text-accent transition"><i class="fa-brands fa-telegram"></i></a><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
</div>


<header class="bg-white text-ink sticky top-0 z-40 border-b border-line">
    <div class="container-x">
        <div class="relative flex items-center justify-between gap-3 lg:gap-6 py-1.5 min-h-[64px]">
            
            <button type="button" class="lg:hidden text-2xl -ml-1 text-ink relative z-10" @click="mobileMenu = true" aria-label="Menu">
                <i class="fa-solid fa-bars"></i>
            </button>

            
            <a href="<?php echo e(route('home')); ?>" class="shrink-0 absolute left-1/2 -translate-x-1/2 lg:static lg:translate-x-0" aria-label="<?php echo e($settings['site_name'] ?? 'Rokda'); ?>">
                <img src="<?php echo e(asset('images/rokda logo.jpeg')); ?>" alt="<?php echo e($settings['site_name'] ?? 'Rokda'); ?>" class="h-14 w-auto object-contain">
            </a>

            
            <form action="<?php echo e(route('shop')); ?>" method="GET" class="hidden md:flex flex-1 max-w-xl lg:max-w-2xl mx-auto" data-search>
                <div class="relative w-full">
                    <div class="flex items-stretch h-12 rounded-full border-2 border-accent overflow-hidden bg-white">
                        <input type="text" name="q" value="<?php echo e(request('q')); ?>" placeholder="<?php echo e(__('messages.search_placeholder')); ?>" autocomplete="off" data-search-input
                               class="flex-1 min-w-0 pl-4 pr-3 text-ink text-sm bg-white placeholder:text-muted focus:outline-none">
                        <button type="submit" class="shrink-0 px-5 bg-accent text-white font-semibold hover:bg-accent-dark flex items-center gap-2 transition">
                            <i class="fa-solid fa-magnifying-glass"></i><span class="hidden sm:inline">Search</span>
                        </button>
                    </div>
                    <div data-search-results class="hidden absolute top-[calc(100%+6px)] left-0 right-0 bg-white rounded-xl border border-line shadow-2xl overflow-hidden z-50 max-h-[70vh] overflow-y-auto"></div>
                </div>
            </form>

            
            <div class="flex items-center gap-4 sm:gap-6 ml-auto relative z-10">
                <button type="button" class="md:hidden w-9 grid place-items-center text-xl text-ink" @click="searchOpen = !searchOpen" aria-label="Search">
                    <i class="fa-solid fa-magnifying-glass"></i>
                </button>

                <a href="<?php echo e(route('wishlist.index')); ?>" class="hidden sm:flex flex-col items-center gap-0.5 text-ink hover:text-brand transition" aria-label="<?php echo e(__('messages.wishlist')); ?>">
                    <span class="relative">
                        <i class="fa-regular fa-heart text-xl"></i>
                        <span data-wishlist-count class="absolute -top-1.5 -right-2 min-w-[16px] h-4 px-1 rounded-full bg-accent text-white text-[10px] font-bold grid place-items-center"><?php echo e($wishlistCount ?? 0); ?></span>
                    </span>
                    <span class="text-[11px] font-medium"><?php echo e(__('messages.wishlist')); ?></span>
                </a>

                <button type="button" class="flex flex-col items-center gap-0.5 text-ink hover:text-brand transition" @click="cartOpen = true" aria-label="<?php echo e(__('messages.cart')); ?>">
                    <span class="relative">
                        <i class="fa-solid fa-cart-shopping text-xl"></i>
                        <span data-cart-count class="absolute -top-1.5 -right-2 min-w-[16px] h-4 px-1 rounded-full bg-accent text-white text-[10px] font-bold grid place-items-center"><?php echo e($cartCount ?? 0); ?></span>
                    </span>
                    <span class="text-[11px] font-medium hidden sm:block"><?php echo e(__('messages.cart')); ?></span>
                </button>

                <a href="<?php echo e(route('account')); ?>" class="hidden sm:flex flex-col items-center gap-0.5 text-ink hover:text-brand transition" aria-label="<?php echo e(__('messages.account')); ?>">
                    <i class="fa-regular fa-user text-xl"></i>
                    <span class="text-[11px] font-medium"><?php echo e(__('messages.account')); ?></span>
                </a>
            </div>
        </div>

        
        <div x-show="searchOpen" x-cloak x-transition class="md:hidden pb-3">
            <form action="<?php echo e(route('shop')); ?>" method="GET" class="relative">
                <input type="text" name="q" value="<?php echo e(request('q')); ?>" placeholder="<?php echo e(__('messages.search_placeholder')); ?>"
                       class="w-full h-11 rounded-lg pl-4 pr-12 text-ink text-sm bg-canvas border border-line placeholder:text-muted focus:outline-none focus:border-brand">
                <button type="submit" class="absolute right-1 top-1 bottom-1 px-4 rounded-md bg-accent text-white">
                    <i class="fa-solid fa-magnifying-glass"></i>
                </button>
            </form>
        </div>
    </div>

    
    <nav class="hidden lg:block bg-accent text-white" x-data="{ allCats: false }">
        <div class="container-x">
            <div class="flex items-stretch gap-1 h-11">
                
                <div class="relative shrink-0" @click.outside="allCats = false">
                    <button type="button" @click="allCats = !allCats"
                            class="flex items-center gap-2 h-11 px-4 hover:bg-white/15 font-semibold text-sm transition">
                        <i class="fa-solid fa-bars"></i> All Categories
                        <i class="fa-solid fa-chevron-down text-[10px] transition" :class="allCats ? 'rotate-180' : ''"></i>
                    </button>
                    <div x-show="allCats" x-cloak @click="allCats = false"
                         x-transition:enter="transition ease-out duration-150" x-transition:enter-start="opacity-0 -translate-y-1" x-transition:enter-end="opacity-100 translate-y-0"
                         class="absolute left-0 top-full w-72 bg-white text-ink rounded-b-xl shadow-2xl border border-line z-50 py-2">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $navCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <a href="<?php echo e(route('shop', ['category' => $cat->slug])); ?>"
                               class="flex items-center gap-3 px-4 py-2.5 text-sm hover:bg-accent-light hover:text-accent transition">
                                <i class="<?php echo e($cat->icon ?? 'fa-solid fa-tag'); ?> w-5 text-center text-accent"></i><?php echo e($cat->name); ?>

                            </a>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </div>
                </div>

                
                <ul class="flex items-stretch overflow-x-auto no-scrollbar flex-1 text-sm font-medium">
                    <li><a href="<?php echo e(route('home')); ?>" class="flex items-center px-3 h-11 whitespace-nowrap hover:bg-white/15 transition <?php echo e(request()->routeIs('home') ? 'bg-white/15' : ''); ?>"><?php echo e(__('messages.home')); ?></a></li>
                    <li><a href="<?php echo e(route('shop')); ?>" class="flex items-center px-3 h-11 whitespace-nowrap hover:bg-white/15 transition <?php echo e(request()->routeIs('shop') && !request('category') ? 'bg-white/15' : ''); ?>"><?php echo e(__('messages.shop')); ?></a></li>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $navCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <li><a href="<?php echo e(route('shop', ['category' => $cat->slug])); ?>" class="flex items-center px-3 h-11 whitespace-nowrap hover:bg-white/15 transition <?php echo e(request('category') === $cat->slug ? 'bg-white/15' : ''); ?>"><?php echo e($cat->name); ?></a></li>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    <li><a href="<?php echo e(route('contact')); ?>" class="flex items-center px-3 h-11 whitespace-nowrap hover:bg-white/15 transition <?php echo e(request()->routeIs('contact') ? 'bg-white/15' : ''); ?>"><?php echo e(__('messages.contact')); ?></a></li>
                </ul>
            </div>
        </div>
    </nav>
</header>


<div x-show="mobileMenu" x-cloak class="fixed inset-0 z-50 lg:hidden" @keydown.escape.window="mobileMenu = false">
    <div x-show="mobileMenu" x-transition.opacity class="absolute inset-0 bg-black/50" @click="mobileMenu = false"></div>
    <div x-show="mobileMenu"
         x-transition:enter="transition ease-out duration-200" x-transition:enter-start="-translate-x-full" x-transition:enter-end="translate-x-0"
         x-transition:leave="transition ease-in duration-150" x-transition:leave-start="translate-x-0" x-transition:leave-end="-translate-x-full"
         class="absolute inset-y-0 left-0 w-80 max-w-[85%] bg-white flex flex-col">
        <div class="bg-white border-b border-line p-4 flex items-center justify-between">
            <a href="<?php echo e(route('home')); ?>" aria-label="<?php echo e($settings['site_name'] ?? 'Rokda'); ?>"><img src="<?php echo e(asset('images/rokda logo.jpeg')); ?>" alt="<?php echo e($settings['site_name'] ?? 'Rokda'); ?>" class="h-11 w-auto object-contain"></a>
            <button @click="mobileMenu = false" class="text-2xl text-ink"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <nav class="flex-1 overflow-y-auto p-2">
            <a href="<?php echo e(route('home')); ?>" class="flex items-center gap-3 px-3 py-3 rounded-lg hover:bg-canvas"><i class="fa-solid fa-house w-5 text-brand"></i><?php echo e(__('messages.home')); ?></a>
            <a href="<?php echo e(route('shop')); ?>" class="flex items-center gap-3 px-3 py-3 rounded-lg hover:bg-canvas"><i class="fa-solid fa-bag-shopping w-5 text-brand"></i><?php echo e(__('messages.shop')); ?></a>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $navCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <a href="<?php echo e(route('shop', ['category' => $cat->slug])); ?>" class="flex items-center gap-3 px-3 py-3 rounded-lg hover:bg-canvas"><i class="<?php echo e($cat->icon ?? 'fa-solid fa-tag'); ?> w-5 text-brand"></i><?php echo e($cat->name); ?></a>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            <a href="<?php echo e(route('wishlist.index')); ?>" class="flex items-center gap-3 px-3 py-3 rounded-lg hover:bg-canvas"><i class="fa-regular fa-heart w-5 text-brand"></i><?php echo e(__('messages.wishlist')); ?></a>
            <a href="<?php echo e(route('contact')); ?>" class="flex items-center gap-3 px-3 py-3 rounded-lg hover:bg-canvas"><i class="fa-solid fa-headset w-5 text-brand"></i><?php echo e(__('messages.contact')); ?></a>
            <a href="<?php echo e(route('account')); ?>" class="flex items-center gap-3 px-3 py-3 rounded-lg hover:bg-canvas"><i class="fa-regular fa-user w-5 text-brand"></i><?php echo e(__('messages.account')); ?></a>
            <a href="<?php echo e(route('track')); ?>" class="flex items-center gap-3 px-3 py-3 rounded-lg hover:bg-canvas"><i class="fa-solid fa-truck-fast w-5 text-brand"></i>Track Order</a>
        </nav>
    </div>
</div>
<?php /**PATH F:\extrain web all project\rokdabd.com\rokda e commarce laravel\resources\views/partials/header.blade.php ENDPATH**/ ?>