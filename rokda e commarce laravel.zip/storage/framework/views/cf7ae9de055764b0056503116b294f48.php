<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($items->isEmpty()): ?>
    <div class="text-center text-muted py-12">
        <i class="fa-solid fa-cart-shopping text-4xl mb-3 opacity-30"></i>
        <p>Your cart is empty.</p>
        <a href="<?php echo e(route('shop')); ?>" class="text-brand font-semibold text-sm mt-2 inline-block">Start shopping →</a>
    </div>
<?php else: ?>
    <div class="space-y-3">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <div class="flex gap-3 items-center">
                <a href="<?php echo e(route('product.show', $item['product'])); ?>" class="w-16 h-16 rounded-lg bg-canvas overflow-hidden shrink-0">
                    <img src="<?php echo e(image_url($item['product']->main_image, $item['product']->name)); ?>" alt="" class="w-full h-full object-cover">
                </a>
                <div class="flex-1 min-w-0">
                    <a href="<?php echo e(route('product.show', $item['product'])); ?>" class="text-sm font-semibold clamp-2 leading-snug"><?php echo e($item['product']->name); ?></a>
                    <div class="text-xs text-muted mt-0.5"><?php echo e($item['quantity']); ?> × <?php echo e(bdt($item['product']->price)); ?></div>
                    <div class="text-brand font-bold text-sm"><?php echo e(bdt($item['subtotal'])); ?></div>
                </div>
                <button type="button" data-remove-cart="<?php echo e($item['key']); ?>" class="w-8 h-8 grid place-items-center text-muted hover:text-sale transition" aria-label="Remove">
                    <i class="fa-solid fa-trash-can"></i>
                </button>
            </div>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
    </div>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php /**PATH F:\extrain web all project\rokdabd.com\rokda e commarce laravel\resources\views\partials\cart-items.blade.php ENDPATH**/ ?>