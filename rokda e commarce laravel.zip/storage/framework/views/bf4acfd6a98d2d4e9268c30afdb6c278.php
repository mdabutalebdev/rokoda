<?php $editing = $banner->exists; ?>

<form method="POST" action="<?php echo e($editing ? route('admin.banners.update', $banner) : route('admin.banners.store')); ?>" enctype="multipart/form-data" class="bg-white rounded-xl border border-line p-5 max-w-xl space-y-4">
    <?php echo csrf_field(); ?>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($editing): ?> <?php echo method_field('PUT'); ?> <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($banner->image): ?>
        <img src="<?php echo e(image_url($banner->image, 'Banner')); ?>" class="w-full h-40 object-cover rounded-lg border border-line bg-canvas">
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <div>
        <label class="block text-sm font-medium mb-1">Title</label>
        <input type="text" name="title" value="<?php echo e(old('title', $banner->title)); ?>" class="w-full h-11 rounded-lg border border-line px-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30">
    </div>
    <div class="grid sm:grid-cols-2 gap-4">
        <div>
            <label class="block text-sm font-medium mb-1">Type <span class="text-sale">*</span></label>
            <select name="type" class="w-full h-11 rounded-lg border border-line px-3 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-brand/30">
                <option value="hero" <?php if(old('type', $banner->type)==='hero'): echo 'selected'; endif; ?>>Center Slider (Hero)</option>
                <option value="left" <?php if(old('type', $banner->type)==='left'): echo 'selected'; endif; ?>>Left Promo Banner</option>
                <option value="right" <?php if(old('type', $banner->type)==='right'): echo 'selected'; endif; ?>>Right Promo Banner</option>
            </select>
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Order (sort)</label>
            <input type="number" name="sort_order" value="<?php echo e(old('sort_order', $banner->sort_order ?? 0)); ?>" class="w-full h-11 rounded-lg border border-line px-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30">
        </div>
    </div>
    <div>
        <label class="block text-sm font-medium mb-1">Link</label>
        <input type="text" name="link" value="<?php echo e(old('link', $banner->link)); ?>" placeholder="/shop?flash=1" class="w-full h-11 rounded-lg border border-line px-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30">
    </div>
    <div>
        <label class="block text-sm font-medium mb-1">Upload Image</label>
        <input type="file" name="image" accept="image/*" class="w-full text-sm file:mr-3 file:py-2 file:px-3 file:rounded-lg file:border-0 file:bg-brand-light file:text-brand file:font-semibold">
        <label class="block text-xs text-muted mb-1 mt-2">Or Image URL</label>
        <input type="text" name="image_url" placeholder="https://..." class="w-full h-10 rounded-lg border border-line px-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30">
    </div>
    <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="is_active" value="1" <?php if(old('is_active', $editing ? $banner->is_active : true)): echo 'checked'; endif; ?> class="accent-brand">Active</label>

    <div class="flex gap-2 pt-2">
        <button type="submit" class="btn-brand h-11 px-6"><?php echo e($editing ? 'Update' : 'Save'); ?></button>
        <a href="<?php echo e(route('admin.banners.index')); ?>" class="h-11 px-4 rounded-lg border border-line inline-flex items-center text-sm">Cancel</a>
    </div>
</form>
<?php /**PATH F:\extrain web all project\rokdabd.com\rokda e commarce laravel\resources\views\admin\banners\_form.blade.php ENDPATH**/ ?>