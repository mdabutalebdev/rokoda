<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title' => 'Dashboard']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title' => 'Dashboard']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e($title); ?> - Admin | Rokda</title>

    <link rel="icon" type="image/jpeg" href="<?php echo e(asset('images/rokda logo.jpeg')); ?>">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
</head>
<body class="bg-canvas min-h-screen" x-data="{ sidebar: false }">

    <?php
        $navItems = [
            ['route' => 'admin.dashboard', 'icon' => 'fa-gauge-high', 'label' => 'Dashboard', 'active' => 'admin.dashboard'],
            ['route' => 'admin.products.index', 'icon' => 'fa-box', 'label' => 'Products', 'active' => 'admin.products.*'],
            ['route' => 'admin.categories.index', 'icon' => 'fa-layer-group', 'label' => 'Categories', 'active' => 'admin.categories.*'],
            ['route' => 'admin.banners.index', 'icon' => 'fa-image', 'label' => 'Banners', 'active' => 'admin.banners.*'],
            ['route' => 'admin.category-banners.index', 'icon' => 'fa-panorama', 'label' => 'Category Banners', 'active' => 'admin.category-banners.*'],
            ['route' => 'admin.orders.index', 'icon' => 'fa-bag-shopping', 'label' => 'Orders', 'active' => 'admin.orders.*'],
            ['route' => 'admin.contact_messages.index', 'icon' => 'fa-envelope', 'label' => 'Contact Messages', 'active' => 'admin.contact_messages.*'],
            ['route' => 'admin.requests.index', 'icon' => 'fa-clipboard-list', 'label' => 'Requests', 'active' => 'admin.requests.*'],
            ['route' => 'admin.reviews.index', 'icon' => 'fa-star', 'label' => 'Reviews', 'active' => 'admin.reviews.*'],
            ['route' => 'admin.delivery-charge.index', 'icon' => 'fa-truck-fast', 'label' => 'Delivery Charge', 'active' => 'admin.delivery-charge.*'],
            ['route' => 'admin.settings.edit', 'icon' => 'fa-gear', 'label' => 'Settings', 'active' => 'admin.settings.*'],
            ['route' => 'admin.social-links.index', 'icon' => 'fa-hashtag', 'label' => 'Social Links', 'active' => 'admin.social-links.*'],
        ];
    ?>

    
    <aside class="fixed inset-y-0 left-0 z-40 w-64 bg-brand-dark text-white flex flex-col transition-transform lg:translate-x-0"
           :class="sidebar ? 'translate-x-0' : '-translate-x-full'">
        <div class="h-16 flex items-center gap-2 px-4 border-b border-white/10">
            <span class="bg-white rounded-lg px-2.5 py-1.5 inline-flex">
                <img src="<?php echo e(asset('images/rokda logo.jpeg')); ?>" alt="Rokda" class="h-7 w-auto object-contain">
            </span>
            <span class="text-white/70 font-medium text-sm">Admin</span>
        </div>
        <nav class="flex-1 overflow-y-auto p-3 space-y-1">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $navItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <a href="<?php echo e(route($item['route'])); ?>"
                   class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition <?php echo e(request()->routeIs($item['active']) ? 'bg-white text-brand' : 'text-white/80 hover:bg-white/10'); ?>">
                    <i class="fa-solid <?php echo e($item['icon']); ?> w-5 text-center"></i><?php echo e($item['label']); ?>

                </a>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </nav>
        <div class="p-3 border-t border-white/10">
            <a href="<?php echo e(route('home')); ?>" target="_blank" class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-white/80 hover:bg-white/10"><i class="fa-solid fa-arrow-up-right-from-square w-5 text-center"></i>View Site</a>
        </div>
    </aside>

    
    <div x-show="sidebar" x-cloak @click="sidebar=false" class="fixed inset-0 bg-black/50 z-30 lg:hidden"></div>

    
    <div class="lg:ml-64">
        <header class="h-16 bg-white border-b border-line sticky top-0 z-20 flex items-center gap-3 px-4 lg:px-6">
            <button @click="sidebar=true" class="lg:hidden text-xl"><i class="fa-solid fa-bars"></i></button>
            <h1 class="font-bold text-lg"><?php echo e($title); ?></h1>
            <div class="ml-auto flex items-center gap-3">
                <span class="text-sm text-muted hidden sm:block"><?php echo e(auth()->user()->name); ?></span>
                <span class="w-9 h-9 rounded-full bg-brand text-white grid place-items-center font-bold"><?php echo e(mb_substr(auth()->user()->name, 0, 1)); ?></span>
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button class="h-9 px-3 rounded-lg border border-line text-sm hover:bg-canvas"><i class="fa-solid fa-right-from-bracket"></i></button>
                </form>
            </div>
        </header>

        <main class="p-4 lg:p-6">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
                <div class="bg-brand-light border border-brand/20 text-brand rounded-lg px-4 py-3 text-sm mb-4 flex items-center gap-2"><i class="fa-solid fa-circle-check"></i><?php echo e(session('success')); ?></div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->any()): ?>
                <div class="bg-red-50 border border-red-200 text-sale rounded-lg px-4 py-3 text-sm mb-4">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?><div><?php echo e($error); ?></div><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php echo e($slot); ?>

        </main>
    </div>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH F:\extrain web all project\rokdabd.com\rokda e commarce laravel\resources\views/components/admin-layout.blade.php ENDPATH**/ ?>