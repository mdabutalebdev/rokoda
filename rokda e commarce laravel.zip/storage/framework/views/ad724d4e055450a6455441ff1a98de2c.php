<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => ['title' => 'Site Settings']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Site Settings']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <form method="POST" action="<?php echo e(route('admin.settings.update')); ?>" class="max-w-2xl space-y-6">
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

        <div class="bg-white rounded-xl border border-line p-5 space-y-4">
            <h2 class="font-bold flex items-center gap-2"><i class="fa-solid fa-store text-brand"></i>General Information</h2>
            <div class="grid sm:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium mb-1">Site Name</label>
                    <input type="text" name="site_name" value="<?php echo e($settings['site_name'] ?? ''); ?>" class="w-full h-11 rounded-lg border border-line px-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Tagline</label>
                    <input type="text" name="site_tagline" value="<?php echo e($settings['site_tagline'] ?? ''); ?>" class="w-full h-11 rounded-lg border border-line px-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30">
                </div>
                <div class="sm:col-span-2">
                    <label class="block text-sm font-medium mb-1">Top Bar Text</label>
                    <input type="text" name="topbar_text" value="<?php echo e($settings['topbar_text'] ?? ''); ?>" class="w-full h-11 rounded-lg border border-line px-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30">
                </div>
                <div class="sm:col-span-2">
                    <label class="block text-sm font-medium mb-1">Footer Text</label>
                    <textarea name="footer_text" rows="2" class="w-full rounded-lg border border-line px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30"><?php echo e($settings['footer_text'] ?? ''); ?></textarea>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-xl border border-line p-5 space-y-4">
            <h2 class="font-bold flex items-center gap-2"><i class="fa-solid fa-address-book text-brand"></i>Contact & Social</h2>
            <div class="grid sm:grid-cols-2 gap-4">
                <div><label class="block text-sm font-medium mb-1">Phone</label><input type="text" name="phone" value="<?php echo e($settings['phone'] ?? ''); ?>" class="w-full h-11 rounded-lg border border-line px-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30"></div>
                <div><label class="block text-sm font-medium mb-1">Email</label><input type="text" name="email" value="<?php echo e($settings['email'] ?? ''); ?>" class="w-full h-11 rounded-lg border border-line px-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30"></div>
                <div class="sm:col-span-2"><label class="block text-sm font-medium mb-1">Address</label><input type="text" name="address" value="<?php echo e($settings['address'] ?? ''); ?>" class="w-full h-11 rounded-lg border border-line px-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30"></div>
                <div class="sm:col-span-2"><label class="block text-sm font-medium mb-1">Business Hours <span class="text-xs text-muted">(shown on the Contact page)</span></label><input type="text" name="business_hours" value="<?php echo e($settings['business_hours'] ?? ''); ?>" placeholder="Every day, 9:00 AM – 10:00 PM" class="w-full h-11 rounded-lg border border-line px-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30"></div>
                <div><label class="block text-sm font-medium mb-1">WhatsApp <span class="text-xs text-muted">(digits only, e.g. 8801XXXXXXXXX)</span></label><input type="text" name="whatsapp" value="<?php echo e($settings['whatsapp'] ?? ''); ?>" class="w-full h-11 rounded-lg border border-line px-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30"></div>
                <div><label class="block text-sm font-medium mb-1">Facebook</label><input type="text" name="facebook" value="<?php echo e($settings['facebook'] ?? ''); ?>" class="w-full h-11 rounded-lg border border-line px-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30"></div>
                <div><label class="block text-sm font-medium mb-1">Instagram</label><input type="text" name="instagram" value="<?php echo e($settings['instagram'] ?? ''); ?>" class="w-full h-11 rounded-lg border border-line px-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30"></div>
                <div><label class="block text-sm font-medium mb-1">YouTube</label><input type="text" name="youtube" value="<?php echo e($settings['youtube'] ?? ''); ?>" class="w-full h-11 rounded-lg border border-line px-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30"></div>
                <div><label class="block text-sm font-medium mb-1">TikTok</label><input type="text" name="tiktok" value="<?php echo e($settings['tiktok'] ?? ''); ?>" class="w-full h-11 rounded-lg border border-line px-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30"></div>
                <div><label class="block text-sm font-medium mb-1">Telegram</label><input type="text" name="telegram" value="<?php echo e($settings['telegram'] ?? ''); ?>" class="w-full h-11 rounded-lg border border-line px-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30"></div>
            </div>
        </div>

        <div class="bg-white rounded-xl border border-line p-5 space-y-4">
            <h2 class="font-bold flex items-center gap-2"><i class="fa-solid fa-mobile-screen text-brand"></i>Mobile Banking (bKash / Nagad)</h2>
            <p class="text-xs text-muted">When a customer selects "Mobile Banking" at checkout, they send money to this number and provide the Transaction ID.</p>
            <div class="grid sm:grid-cols-2 gap-4">
                <div><label class="block text-sm font-medium mb-1">bKash Number</label><input type="text" name="bkash_number" value="<?php echo e($settings['bkash_number'] ?? ''); ?>" placeholder="01XXXXXXXXX" class="w-full h-11 rounded-lg border border-line px-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30"></div>
                <div><label class="block text-sm font-medium mb-1">Nagad Number</label><input type="text" name="nagad_number" value="<?php echo e($settings['nagad_number'] ?? ''); ?>" placeholder="01XXXXXXXXX" class="w-full h-11 rounded-lg border border-line px-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30"></div>
                <div class="sm:col-span-2"><label class="block text-sm font-medium mb-1">Payment Instruction <span class="text-xs text-muted">(optional)</span></label><input type="text" name="payment_instruction" value="<?php echo e($settings['payment_instruction'] ?? ''); ?>" placeholder="Send Money first, then enter the details below." class="w-full h-11 rounded-lg border border-line px-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30"></div>
            </div>
        </div>

        <div class="bg-white rounded-xl border border-line p-5 space-y-4">
            <h2 class="font-bold flex items-center gap-2"><i class="fa-solid fa-truck text-brand"></i>Delivery Charges</h2>
            <div class="grid sm:grid-cols-2 gap-4">
                <div><label class="block text-sm font-medium mb-1">Inside Dhaka (BDT)</label><input type="number" name="shipping_inside_dhaka" value="<?php echo e($settings['shipping_inside_dhaka'] ?? 60); ?>" class="w-full h-11 rounded-lg border border-line px-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30"></div>
                <div><label class="block text-sm font-medium mb-1">Outside Dhaka (BDT)</label><input type="number" name="shipping_outside_dhaka" value="<?php echo e($settings['shipping_outside_dhaka'] ?? 120); ?>" class="w-full h-11 rounded-lg border border-line px-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30"></div>
            </div>
        </div>

        <button type="submit" class="btn-brand h-11 px-8"><i class="fa-solid fa-floppy-disk"></i>Save Settings</button>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php /**PATH F:\extrain web all project\rokdabd.com\rokda e commarce laravel\resources\views\admin\settings\edit.blade.php ENDPATH**/ ?>