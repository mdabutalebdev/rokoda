<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['title' => 'চেকআউট']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'চেকআউট']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <div class="container-x py-6"
         x-data="{
            zone: 'inside_dhaka',
            subtotal: <?php echo e((int) $subtotal); ?>,
            inside: <?php echo e((int) $insideFee); ?>,
            outside: <?php echo e((int) $outsideFee); ?>,
            freeThreshold: <?php echo e((int) $freeThreshold); ?>,
            district: '',
            thanas: [],
            geo: <?php echo e(Illuminate\Support\Js::from($bdGeo)); ?>,
            onDistrictChange() {
                this.thanas = this.district && this.geo[this.district] ? this.geo[this.district] : [];
                this.zone = (this.district === 'ঢাকা' || this.district === 'Dhaka') ? 'inside_dhaka' : 'outside_dhaka';
            },
            get shipping() {
                if (this.subtotal >= this.freeThreshold) return 0;
                return this.zone === 'inside_dhaka' ? this.inside : this.outside;
            },
            get total() { return this.subtotal + this.shipping },
            fmt(n) { return 'BDT ' + n.toLocaleString('en-US') }
         }">

        <h1 class="text-xl font-extrabold mb-4">চেকআউট</h1>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->any()): ?>
            <div class="bg-red-50 border border-red-200 text-sale rounded-lg p-3 mb-4 text-sm">
                <ul class="list-disc list-inside">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?><li><?php echo e($error); ?></li><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </ul>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <form method="POST" action="<?php echo e(route('checkout.store')); ?>" class="grid lg:grid-cols-[1fr_360px] gap-6">
            <?php echo csrf_field(); ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($buy): ?>
                <input type="hidden" name="buy" value="<?php echo e($buy); ?>">
                <input type="hidden" name="qty" value="<?php echo e($buyQty); ?>">
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <div class="space-y-5">
                
                <div class="bg-white rounded-xl border border-line p-5">
                    <h2 class="font-bold mb-4 flex items-center gap-2 text-sm">Shipping Details</h2>
                    <div class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium mb-1">আপনার নাম <span class="text-sale">*</span></label>
                            <input type="text" name="name" value="<?php echo e(old('name', auth()->user()?->name)); ?>" placeholder="আপনার নাম লিখুন" required class="w-full h-11 rounded-lg border border-line px-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium mb-1">মোবাইল নাম্বার <span class="text-sale">*</span></label>
                            <div class="flex items-center h-11 rounded-lg border border-line overflow-hidden focus-within:ring-2 focus-within:ring-brand/30">
                                <div class="px-3 bg-canvas border-r border-line h-full flex items-center justify-center text-lg shrink-0">
                                    🇧🇩
                                </div>
                                <input type="text" name="phone" value="<?php echo e(old('phone', auth()->user()?->phone)); ?>" required placeholder="01XXXXXXX" class="w-full h-full px-3 text-sm focus:outline-none">
                            </div>
                        </div>

                        <div>
                            <label class="block text-sm font-medium mb-1">জেলা <span class="text-sale">*</span></label>
                            <select name="district" x-model="district" @change="onDistrictChange()" required class="w-full h-11 rounded-lg border border-line px-3 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-brand/30">
                                <option value="">জেলা সিলেক্ট করুন</option>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = array_keys($bdGeo); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                    <option value="<?php echo e($district); ?>" <?php if(old('district') === $district): echo 'selected'; endif; ?>><?php echo e($district); ?></option>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            </select>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium mb-1">থানা/উপজেলা <span class="text-sale">*</span></label>
                            <select name="thana" required :disabled="!thanas.length" class="w-full h-11 rounded-lg border border-line px-3 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-brand/30 disabled:bg-canvas disabled:text-muted">
                                <option value="">থানা/উপজেলা সিলেক্ট করুন</option>
                                <template x-for="t in thanas" :key="t">
                                    <option :value="t" x-text="t" :selected="'<?php echo e(old('thana')); ?>' === t"></option>
                                </template>
                            </select>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium mb-1">সম্পূর্ণ ঠিকানা <span class="text-sale">*</span></label>
                            <textarea name="address" required rows="2" placeholder="গ্রাম/এলাকা/রাস্তা/বাড়ী" class="w-full rounded-lg border border-line px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30"><?php echo e(old('address')); ?></textarea>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium mb-1">অর্ডার নোট <span class="text-muted font-normal">(Optional)</span></label>
                            <textarea name="notes" rows="2" placeholder="কিছু বলার থাকলে এখানে লিখুন।" class="w-full rounded-lg border border-line px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30"><?php echo e(old('notes')); ?></textarea>
                        </div>
                    </div>
                </div>

                
                <input type="hidden" name="delivery_zone" :value="zone">

                
                <?php $paySettings = \App\Models\SiteSetting::getAll(); ?>
                <div class="bg-white rounded-xl border border-line p-5" x-data="{ pay: 'cod', channel: '' }">
                    <h2 class="font-bold mb-4 flex items-center gap-2 text-sm"><i class="fa-solid fa-wallet text-brand"></i>পেমেন্ট পদ্ধতি</h2>
                    <div class="space-y-3">
                        <label class="flex items-center gap-3 border rounded-lg p-3 cursor-pointer" :class="pay==='cod' ? 'border-brand bg-brand-light' : 'border-line'">
                            <input type="radio" name="payment_method" value="cod" x-model="pay" class="accent-brand" checked>
                            <span class="text-sm font-medium flex items-center gap-2"><i class="fa-solid fa-money-bill-wave text-brand"></i>ক্যাশ অন ডেলিভারি</span>
                        </label>
                        <label class="flex items-center gap-3 border rounded-lg p-3 cursor-pointer" :class="pay==='mobile_banking' ? 'border-brand bg-brand-light' : 'border-line'">
                            <input type="radio" name="payment_method" value="mobile_banking" x-model="pay" class="accent-brand">
                            <span class="text-sm font-medium flex items-center gap-2"><i class="fa-solid fa-mobile-screen text-brand"></i>মোবাইল ব্যাংকিং (বিকাশ / নগদ)</span>
                        </label>
                    </div>

                    
                    <div x-show="pay==='mobile_banking'" x-cloak class="mt-4 border-t border-line pt-4 space-y-4">
                        <div class="bg-brand-light rounded-lg p-3 text-sm space-y-1.5">
                            <p class="font-semibold text-ink"><?php echo e($paySettings['payment_instruction'] ?? 'অনুগ্রহ করে আগে পেমেন্ট সম্পন্ন করুন, তারপর নিচের তথ্যগুলো দিন।'); ?></p>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($paySettings['bkash_number'])): ?>
                                <p class="text-ink/80"><span class="inline-block w-16 font-semibold">bKash</span>: <span class="font-bold text-brand"><?php echo e($paySettings['bkash_number']); ?></span> <span class="text-muted text-xs">(Send Money)</span></p>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($paySettings['nagad_number'])): ?>
                                <p class="text-ink/80"><span class="inline-block w-16 font-semibold">Nagad</span>: <span class="font-bold text-brand"><?php echo e($paySettings['nagad_number']); ?></span> <span class="text-muted text-xs">(Send Money)</span></p>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>

                        <div>
                            <label class="block text-sm font-medium mb-1.5">কোন মাধ্যমে পাঠিয়েছেন? <span class="text-sale">*</span></label>
                            <div class="flex gap-3">
                                <label class="flex items-center gap-2 border rounded-lg px-3 h-11 cursor-pointer flex-1" :class="channel==='bkash' ? 'border-brand bg-brand-light' : 'border-line'">
                                    <input type="radio" name="payment_channel" value="bkash" x-model="channel" class="accent-brand" :required="pay==='mobile_banking'">
                                    <span class="text-sm font-medium">bKash</span>
                                </label>
                                <label class="flex items-center gap-2 border rounded-lg px-3 h-11 cursor-pointer flex-1" :class="channel==='nagad' ? 'border-brand bg-brand-light' : 'border-line'">
                                    <input type="radio" name="payment_channel" value="nagad" x-model="channel" class="accent-brand" :required="pay==='mobile_banking'">
                                    <span class="text-sm font-medium">Nagad</span>
                                </label>
                            </div>
                        </div>

                        <div>
                            <label class="block text-sm font-medium mb-1">যে নম্বর থেকে পাঠিয়েছেন <span class="text-sale">*</span></label>
                            <input type="text" name="payment_sender_number" value="<?php echo e(old('payment_sender_number')); ?>" placeholder="01XXXXXXXXX" :required="pay==='mobile_banking'" class="w-full h-11 rounded-lg border border-line px-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30">
                        </div>

                        <div>
                            <label class="block text-sm font-medium mb-1">Transaction ID (TrxID) <span class="text-sale">*</span></label>
                            <input type="text" name="payment_txn_id" value="<?php echo e(old('payment_txn_id')); ?>" placeholder="যেমন: 8N7A6D5EE7M" :required="pay==='mobile_banking'" class="w-full h-11 rounded-lg border border-line px-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30">
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="bg-white rounded-xl border border-line p-5 h-fit lg:sticky lg:top-32">
                <h2 class="font-bold mb-4 flex items-center gap-2 text-sm"><i class="fa-solid fa-receipt text-brand"></i>Order Summary</h2>
                <div class="space-y-3 max-h-64 overflow-y-auto">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <div class="flex gap-3 items-center">
                            <div class="w-14 h-14 rounded-lg bg-canvas overflow-hidden shrink-0">
                                <img src="<?php echo e(image_url($item['product']->main_image, $item['product']->name)); ?>" class="w-full h-full object-cover">
                            </div>
                            <div class="flex-1 min-w-0">
                                <div class="text-sm font-semibold clamp-2"><?php echo e($item['product']->name); ?></div>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($item['options'])): ?>
                                    <div class="text-[11px] text-muted">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $item['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                            <span class="mr-1"><?php echo e($k); ?>: <span class="text-ink font-semibold"><?php echo e($v); ?></span></span>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                    </div>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                <div class="text-xs text-muted"><?php echo e($item['quantity']); ?> × <?php echo e(bdt($item['product']->price)); ?></div>
                            </div>
                            <div class="text-sm font-bold"><?php echo e(bdt($item['subtotal'])); ?></div>
                        </div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </div>

                <div class="border-t border-line mt-4 pt-4 space-y-2 text-sm">
                    <div class="flex justify-between"><span class="text-muted">মোট:</span><span class="font-semibold"><?php echo e(bdt($subtotal)); ?></span></div>
                    <div class="flex justify-between"><span class="text-muted">ডেলিভারি চার্জ:</span><span class="font-semibold" x-text="fmt(shipping)"></span></div>
                    <div class="flex justify-between text-lg font-bold border-t border-line pt-2"><span>সর্বমোট:</span><span class="text-brand" x-text="fmt(total)"></span></div>
                </div>

                <button type="submit" class="btn-accent w-full h-12 mt-5 text-base">
                    <i class="fa-solid fa-circle-check"></i>অর্ডার নিশ্চিত করুন
                </button>
                <p class="text-xs text-muted text-center mt-3"><i class="fa-solid fa-lock mr-1"></i>নিরাপদ ও সুরক্ষিত চেকআউট</p>
            </div>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH F:\extrain web all project\rokdabd.com\rokda e commarce laravel\resources\views\checkout.blade.php ENDPATH**/ ?>